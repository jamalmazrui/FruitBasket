/*
content of cs3_fruit.cs
Fruit Basket program in C# 3.0
Public domain by Jamal Mazrui
June 1, 2010
*/

// Import namespaces
using System;
using System.Windows.Forms;

// Define class
class FruitBasket {

// Define entry point of program
    static void Main() {
// Show the .NET Framework version
MessageBox.Show(".NET Framework " + System.Runtime.InteropServices.RuntimeEnvironment.GetSystemVersion());
// Create controls;
        var tlp = new TableLayoutPanel {ColumnCount = 3, RowCount = 2};
        var lblFruit = new Label {Text = "&Fruit:"};
        var txtFruit = new TextBox();
        var btnAdd = new Button {Text = "&Add"};
        var lblBasket = new Label {Text = "&Basket:"};
        var lstBasket = new ListBox();
        var btnDelete = new Button {Text = "&Delete"};

// Define Add event handler;
        btnAdd.Click += (o, e) => {
            var sFruit = txtFruit.Text.Trim();
            if (sFruit == "") MessageBox.Show("No fruit to add!", "Alert");
            else {
                lstBasket.Items.Add(sFruit);
                txtFruit.Clear();
                lstBasket.SelectedIndex = lstBasket.Items.Count - 1;
            }
        };

// Define Delete event handler;
        btnDelete.Click += (o,e) => {
            var iFruit = lstBasket.SelectedIndex;
            if (iFruit == -1) MessageBox.Show("No fruit to delete!", "Alert");
            else {
                lstBasket.Items.RemoveAt(iFruit);
                if (iFruit == lstBasket.Items.Count) iFruit--;
                lstBasket.SelectedIndex = iFruit;
            }
        };

// Finalize dialog;
        tlp.Controls.AddRange(new Control[] {lblFruit, txtFruit, btnAdd, lblBasket, lstBasket, btnDelete});
        var dlg = new Form {Text = "Fruit Basket", AcceptButton = btnAdd, StartPosition = FormStartPosition.CenterScreen, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink};
        dlg.Controls.Add(tlp);

// Define closing event handler
        dlg.Closing += (o, e) => e.Cancel = (MessageBox.Show("Close program?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.No);
        dlg.ShowDialog();
    } // Main method
} // FruitBasket class

// End of cs3_fruit.cs
