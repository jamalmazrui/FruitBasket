#Fruit basket program in Iron Python
#Public domain by Jamal Mazrui

import clr
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
from System.Windows.Forms import *
from System.Drawing import *
import System
from System import *

class FruitBasket(Form):
  def __init__(self):
    flpMain = FlowLayoutPanel()
    flpMain.SuspendLayout()
    flpMain.AutoSize = True
    flpMain.AutoSizeMode = AutoSizeMode.GrowAndShrink
    flpMain.FlowDirection = FlowDirection.TopDown
    
    flpData = FlowLayoutPanel()
    flpData.SuspendLayout()
    flpData.AutoSize = True
    flpData.AutoSizeMode = AutoSizeMode.GrowAndShrink
    flpData.FlowDirection = FlowDirection.LeftToRight
    
    lblFruit = Label()
    lblFruit.Text = "&Fruit:"
    flpData.Controls.Add(lblFruit)
    
    self.txtFruit = TextBox()
    self.txtFruit.AccessibleName = lblFruit.Text.Replace("&", "")
    flpData.Controls.Add(self.txtFruit)
    
    lblBasket = Label()
    lblBasket.Text = "&Basket:"
    flpData.Controls.Add(lblBasket)
    
    self.lstBasket = ListBox()
    self.lstBasket.AccessibleName = lblBasket.Text.Replace("&", "")
    flpData.Controls.Add(self.lstBasket)
    
    flpData.ResumeLayout()
    flpMain.Controls.Add(flpData)
    
    flpButtons = FlowLayoutPanel()
    flpButtons.SuspendLayout()
    flpButtons.Anchor = AnchorStyles.None
    flpButtons.AutoSize = True
    flpButtons.AutoSizeMode = AutoSizeMode.GrowAndShrink
    flpButtons.FlowDirection = FlowDirection.LeftToRight
    
    btnAdd = Button()
    btnAdd.Text = "&Add"
    btnAdd.AccessibleName = btnAdd.Text.Replace("&", "")
    btnAdd.Click += self.OnAddButtonClick
    flpButtons.Controls.Add(btnAdd)
    
    btnDelete = Button()
    btnDelete.Text = "&Delete"
    btnDelete.AccessibleName = btnDelete.Text.Replace("&", "")
    btnDelete.Click += self.OnDeleteButtonClick
    flpButtons.Controls.Add(btnDelete)
    
    flpButtons.ResumeLayout()
    flpMain.Controls.Add(flpButtons)
    
    self.Controls.Add(flpMain)
    self.AcceptButton = btnAdd
    self.Closing += self.OnFruitBasketClosing
    self.StartPosition = FormStartPosition.CenterScreen
    self.Text = "Fruit Basket"

    self.ResumeLayout()
#    self.ShowDialog()
#    self.Show()

  def OnAddButtonClick(self, *args):
    sFruit = self.txtFruit.Text.Trim()
    if sFruit == "" :
      MessageBox.Show("No fruit to add!", "Alert");
      return

    self.lstBasket.Items.Insert(0, sFruit)
    self.lstBasket.SelectedIndex = 0
    self.txtFruit.Clear()

  def OnDeleteButtonClick(self, *args):
    iFruit = self.lstBasket.SelectedIndex
    if iFruit == -1 :
      MessageBox.Show("No fruit to delete!", "Alert");
      return

    self.lstBasket.Items.RemoveAt(iFruit);
    if iFruit > self.lstBasket.Items.Count - 1 :
      iFruit = self.lstBasket.Items.Count - 1

    self.lstBasket.SelectedIndex = iFruit

  def OnFruitBasketClosing(self, *args):
    if MessageBox.Show("Exit program?", "Confirm", MessageBoxButtons.OKCancel) == DialogResult.Cancel :
      args[1].Cancel = True

Application.Run(FruitBasket())
