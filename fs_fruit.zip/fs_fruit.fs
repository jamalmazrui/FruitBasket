// Uncomment the following line for syntax that does not require indentation
//# indent "off"

(*
content of fs_fruit.fs
// Fruit Basket program in F#
// Public domain by Jamal Mazrui
*)

// Import namespaces
open System
open System.Windows.Forms

// Create controls
let tlp = new TableLayoutPanel(ColumnCount = 3, RowCount = 2)
let lblFruit = new Label(Text = "&Fruit:", Parent = tlp)
let txtFruit = new TextBox(Parent = tlp)
let btnAdd = new Button(Text = "&Add", Parent = tlp)
let lblBasket = new Label(Text = "&Basket:", Parent = tlp)
let lstBasket = new ListBox(Parent = tlp)
let btnDelete = new Button(Text = "&Delete", Parent = tlp)

// Define Add event handler
btnAdd.Click.Add(fun o -> 
    let sFruit = txtFruit.Text
    if sFruit = "" then
        ignore(MessageBox.Show("No fruit to add!"), "Alert")
    else
        txtFruit.Clear()
        let iIndex = lstBasket.Items.Add(sFruit)
        lstBasket.SelectedIndex <- iIndex)

// Define Delete event handler
btnDelete.Click.Add(fun o ->  
    let iIndex = lstBasket.SelectedIndex
    if iIndex = -1 then 
        ignore(MessageBox.Show("No fruit to delete."), "Alert")
    else
        lstBasket.Items.RemoveAt(iIndex)
        if iIndex = lstBasket.Items.Count then lstBasket.SelectedIndex <- iIndex - 1
        else lstBasket.SelectedIndex <- iIndex)

// Finalize dialog
let dlg = new Form(Text = "Fruit Basket", AcceptButton = btnAdd, StartPosition = FormStartPosition.CenterScreen, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink)
dlg.Controls.Add(tlp)
ignore(dlg.ShowDialog())
