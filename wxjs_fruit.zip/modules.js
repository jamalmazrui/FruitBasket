wxjs.modules.gui = new Module("wxjs_gui.dll");
wxjs.modules.gui.load();
