/*
Fruit basket program in JavaScript
Public domain by Jamal Mazrui
*/

// Create the dialog window
dlg = new wxDialog(null, -1, "Fruit Basket", wxDefaultPosition, new  wxSize(513, 176));

// Create the label and edit box for inputting a fruit name, e.g., apple
lblFruit = new wxStaticText(dlg, -1, "&Fruit:", new  wxPoint(14, 14), wxDefaultSize);
txtFruit = new wxTextCtrl(dlg, -1, "", new wxPoint(43, 14), wxDefaultSize);

// Create the label and listbox serving as a basket for fruit
lblBasket = new wxStaticText(dlg, -1, "&Basket:", new wxPoint(251, 14), wxDefaultSize);
lstBasket = new wxListBox(dlg, -1, new wxPoint(293,14), wxDefaultSize, {});

// Create the default, Add button and its event handler
btnAdd = new wxButton(dlg, -1, "&Add", new wxPoint(190, 121), wxDefaultSize);
btnAdd.setDefault();
btnAdd.onClicked = function() {
sValue = txtFruit.value;
if (sValue == "") return wxMessageBox("No fruit to add!", "Alert", wxICON_EXCLAMATION, dlg);

lstBasket.append(sValue);
txtFruit.clear();
iCount = lstBasket.count;
iIndex = iCount - 1;
lstBasket.selection = iIndex;
}

// Create the Delete button and its event handler
btnDelete = new wxButton(dlg, -1, "&Delete", new wxPoint(217, 121), wxDefaultSize);
btnDelete.onClicked = function() {
iIndex = lstBasket.selection;
if (iIndex == -1) return wxMessageBox("No fruit to delete!", "Alert", wxICON_EXCLAMATION, dlg);

lstBasket.deleteItem(iIndex);
iCount = lstBasket.count;
if(iIndex == iCount) iIndex--;
lstBasket.selection = iIndex;
}

// Create the event handler that confirms whether to close the program when Alt+F4 is pressed
dlg.onClose = function (event) {
if (wxMessageBox("Exit program?", "Confirm", wxYES_NO, dlg) == wxYES) dlg.destroy();
}

// Show the dialog
dlg.centre();
dlg.show(true);
