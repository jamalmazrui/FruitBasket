/*
Fruit basket program in Silverlight without Visual Studio
Public domain by Jamal Mazrui
May 24, 2011
*/

// Import namespaces
using System;
using System.Net;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Automation.Peers;
using System.Windows.Automation.Provider;
using System.Windows.Browser;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml;

// Define namespace
namespace FruitBasket {

// Define class
public class App: Application {

// Define entry point of program
public App() {
this.Startup += HandleStartup;
} // App Constructor

void HandleStartup(object sender, StartupEventArgs eventArgs) {
// Create controls;

// Create first row of controls
var lblFruit = new TextBlock {Text = "Fruit:"};
var txtFruit = new TextBox();
AutomationProperties.SetName(txtFruit, lblFruit.Text);
var btnAdd = new Button {Content = "Add"};

// Create second row of controls
var lblBasket = new TextBlock {Text = "Basket:"};
var lstBasket = new ListBox{IsTabStop = true};
AutomationProperties.SetName(lstBasket, lblBasket.Text);
var btnDelete = new Button {Content = "Delete"};

// Define Add event handler;
btnAdd.Click += (o, e) => {
var sFruit = txtFruit.Text;
if (sFruit == "") MessageBox.Show("Alert - No fruit to add!");
else {
lstBasket.Items.Add(sFruit);
txtFruit.Text = "";
lstBasket.SelectedIndex = lstBasket.Items.Count - 1;
}
};

// Define Delete event handler;
btnDelete.Click += (o,e) => {
var iFruit = lstBasket.SelectedIndex;
if (iFruit == -1) MessageBox.Show("Alert - No fruit to delete!");
else {
lstBasket.Items.RemoveAt(iFruit);
if (iFruit == lstBasket.Items.Count) iFruit--;
if (iFruit >=0) lstBasket.SelectedIndex = iFruit;
}
};

// Make Enter in the TextBox invoke the Add button
txtFruit.KeyDown += (o, e) => {
if (e.Key == Key.Enter) {
var peer = new ButtonAutomationPeer(btnAdd); 
var provider = (IInvokeProvider) peer; 
provider.Invoke();  
}
};

// Complete layout

// Horizontal panel with TextBox and Add button
var pnlAdd = new StackPanel {Orientation = Orientation.Horizontal};
foreach (var widget in new UIElement[] {lblFruit, txtFruit, btnAdd}) pnlAdd.Children.Add(widget);

// Horizontal panel with ListBox and Delete button
var pnlDelete = new StackPanel {Orientation = Orientation.Horizontal};
foreach (var widget in new UIElement[] {lblBasket, lstBasket, btnDelete}) pnlDelete.Children.Add(widget);

// Vertical panel containing the two horizontal panels
var pnlMain = new StackPanel {Orientation = Orientation.Vertical};
foreach (var widget in new UIElement[] {pnlAdd, pnlDelete}) pnlMain.Children.Add(widget);

// Set the RootVisual container of the app, and initial focus to the TextBox
this.RootVisual = pnlMain;
HtmlPage.Plugin.Focus();
txtFruit.Focus();
} // Handlestartup method
} // App class
} // FruitBasket namespace
