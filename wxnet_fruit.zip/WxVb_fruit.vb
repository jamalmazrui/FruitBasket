' Content of wxvb_fruit.vb
' Fruit Basket program in Visual Basic 2005 with WxWidgets 2.8
' Public domain by Jamal Mazrui

' Import namespaces
Imports System
Imports System.Drawing
Imports wx

' Derive dialog class
Class FbDialog 
Inherits wx.Dialog 

' Declare control variables
Dim lblFruit, lblBasket As wx.StaticText
Dim txtFruit As wx.TextCtrl
Dim lstBasket As wx.ListBox
Dim btnAdd, btnDelete As wx.Button

' Define add event handler
Sub OnAdd(o As Object, e As wx.Event) 
Dim sValue As String = txtFruit.Value.Trim()
If sValue = "" Then 
MessageDialog.ShowModal("No fruit to add!", "Alert", wxOK)
Else 
lstBasket.Append(sValue)
txtFruit.Clear()
Dim iFruit As Integer = lstBasket.Count - 1
lstBasket.Selection = iFruit
End If
End Sub ' OnAdd

' Define delete event handler
Sub OnDelete(o As Object, e As wx.Event) 
Dim iFruit As Integer = lstBasket.Selection
If iFruit = -1 Then 
MessageDialog.ShowModal("No fruit to delete!", "Alert", wxOK)
Else 
lstBasket.Delete(iFruit)
If iFruit = lstBasket.Count Then iFruit -= 1
lstBasket.Selection = iFruit
End If
End Sub ' OnDelete

' Define close event handler
Sub OnClose(o As Object, e As wx.Event) 
If MessageDialog.ShowModal("Exit program?", "Confirm", wxYES_NO Or wxCANCEL) = wxYES Then Destroy()
End Sub ' OnClose event

' Define dialog constructor
public Sub New() 
MyBase.new(Nothing, wxID_ANY, "Fruit Basket", wxDefaultPosition, New wxSize(513, 176)) 
Centre()

' Specify control properties
lblFruit = New wx.StaticText(me, wxID_ANY, "&Fruit:", New Point(14, 14), wxDefaultSize)
txtFruit = New wx.TextCtrl(me, wxID_ANY, "", New Point(43, 14), wxDefaultSize, 0)

lblFruit = New wx.StaticText(me, wxID_ANY, "&Basket:", New Point(251, 14), wxDefaultSize)
lstBasket = New wx.ListBox(me, New Point(293,14), wxDefaultSize, wxID_ANY, Nothing)

btnAdd = New wx.Button(me, wxID_ANY, "&Add", New Point(190, 121), wxDefaultSize)
btnAdd.SetDefault()
btnDelete = New wx.Button(me, wxID_ANY, "&Delete", New Point(217, 121), wxDefaultSize)

' Connect event handlers
EVT_BUTTON(btnAdd.ID, AddressOf OnAdd)
EVT_BUTTON(btnDelete.ID, AddressOf OnDelete)
EVT_CLOSE(AddressOf OnClose)
End Sub ' FbDialog
End Class ' FbDialog class

' Derive application class
Class FbApp 
Inherits wx.App 

' Display user interface
Public Overrides Function OnInit() As Boolean 
Dim dlg As FbDialog = New FbDialog()
dlg.Show()
Return True
End Function ' OnInit

' Define entry point of program
<STAThread> Shared Sub Main() 
Dim app As FbApp = New FbApp()
app.Run()
End Sub ' Main method
End Class ' FbApp

' End of wxvb_fruit.vb
