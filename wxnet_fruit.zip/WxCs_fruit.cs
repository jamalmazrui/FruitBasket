/*
Content of wxcs_fruit.cs
Fruit basket program in C# 2005 with WxWidgets 2.8
Public domain by Jamal Mazrui
*/

// Import namespaces
using System;
using System.Drawing;
using wx;

// Derive dialog class
class FbDialog : wx.Dialog {

// Declare control variables
wx.StaticText lblFruit, lblBasket;
wx.TextCtrl txtFruit;
wx.ListBox lstBasket;
wx.Button btnAdd, btnDelete;

// Define add event handler
void OnAdd(object o, wx.Event e) {
string sValue = txtFruit.Value.Trim();
if (sValue == "") MessageDialog.ShowModal("No fruit to add!", "Alert", wxOK);
else {
lstBasket.Append(sValue);
txtFruit.Clear();
int iFruit = lstBasket.Count - 1;
lstBasket.Selection = iFruit;
}
} // OnAdd event handler

// Define delete event handler
void OnDelete(object o, wx.Event e) {
int iFruit = lstBasket.Selection;
if (iFruit == -1) MessageDialog.ShowModal("No fruit to delete!", "Alert", wxOK);
else {
lstBasket.Delete(iFruit);
if (iFruit == lstBasket.Count) iFruit--;
lstBasket.Selection = iFruit;
}
} // OnDelete event handler

// Define close event handler
void OnClose(object o, wx.Event e) {
if (MessageDialog.ShowModal("Exit program?", "Confirm", wxYES_NO | wxCANCEL) == wxYES) Destroy();
} // OnClose event handler

// Define dialog constructor
public FbDialog() : base(null, wxID_ANY, "Fruit Basket", wxDefaultPosition, new wxSize(513, 176)) {
Center();

// Specify control properties
lblFruit = new wx.StaticText(this, wxID_ANY, "&Fruit:", new Point(14, 14), wxDefaultSize);
txtFruit = new wx.TextCtrl(this, wxID_ANY, "", new Point(43, 14), wxDefaultSize, 0);

lblBasket = new wx.StaticText(this, wxID_ANY, "&Basket:", new Point(251, 14), wxDefaultSize);
lstBasket = new wx.ListBox(this, new Point(293,14), wxDefaultSize, wxID_ANY, null);

btnAdd = new wx.Button(this, wxID_ANY, "&Add", new Point(190, 121), wxDefaultSize);
btnAdd.SetDefault();
btnDelete = new wx.Button(this, wxID_ANY, "&Delete", new Point(217, 121), wxDefaultSize);

// Connect event handlers
EVT_BUTTON(btnAdd.ID, new EventListener(OnAdd));
EVT_BUTTON(btnDelete.ID, new EventListener(OnDelete));
EVT_CLOSE(new EventListener(OnClose));
} // FbDialog constructor
} // FbDialog class

// Derive application class
class FbApp : wx.App {

// Display user interface
public override bool OnInit() {
FbDialog dlg = new FbDialog();
dlg.Show();
return true;
} // OnInit method

// Define entry point of program
[STAThread]
static void Main() {
FbApp app = new FbApp();
app.Run();
} // Main method
} // FbApp class

// End of wxcs_fruit.cs
