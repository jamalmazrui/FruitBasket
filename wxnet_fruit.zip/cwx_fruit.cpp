/*
Content of cwx_fruit.cpp
Fruit basket program in C++ with WxWidgets 2.8
Compiled with Microsoft Visual C++ 2005 Express
Public domain by Jamal Mazrui
*/

// Import headers
#include "wx/wx.h"

// Derive dialog class
class FbDialog : public wxDialog {

public:
// Declare control variables
wxStaticText *lblFruit, *lblBasket;
wxTextCtrl *txtFruit;
wxListBox *lstBasket;
wxButton *btnAdd, *btnDelete;

// Define add event handler
void OnAdd(wxCommandEvent& WXUNUSED(e)) {
wxString sValue = txtFruit->GetValue().Trim();
if (sValue == wxEmptyString) wxMessageBox(wxT("No fruit to add!"), wxT("Alert"));
else {
lstBasket->Append(sValue);
txtFruit->Clear();
int iFruit = lstBasket->GetCount() - 1;
lstBasket->SetSelection(iFruit);
}
} // OnAdd event handler

// Define delete event handler
void OnDelete(wxCommandEvent& WXUNUSED(e)) {
int iFruit = lstBasket->GetSelection();
if (iFruit == -1) wxMessageBox(wxT("No fruit to delete!"), wxT("Alert"));
else {
lstBasket->Delete(iFruit);
if (iFruit == lstBasket->GetCount()) iFruit--;
lstBasket->SetSelection(iFruit);
}
} // OnDelete event handler

// Define close event handler
void OnClose(wxCloseEvent& e) {
if (wxMessageBox(wxT("Exit program?"), wxT("Confirm"), wxYES_NO | wxCANCEL) == wxYES) Destroy();
} // OnClose event handler

// Define dialog constructor
FbDialog() : wxDialog(NULL, wxID_ANY, wxT("Fruit Basket"), wxDefaultPosition, wxSize(513, 176)) {
Centre();

// Specify control properties
lblFruit = new wxStaticText(this, wxID_ANY, wxT("&Fruit:"), wxPoint(14, 14), wxDefaultSize);
txtFruit = new wxTextCtrl(this, wxID_ANY, wxEmptyString, wxPoint(43, 14), wxDefaultSize, wxTE_LEFT);

lblBasket = new wxStaticText(this, wxID_ANY, wxT("&Basket:"), wxPoint(251, 14), wxDefaultSize);
lstBasket = new wxListBox(this, wxID_ANY, wxPoint(293,14), wxDefaultSize, 0);

btnAdd = new wxButton(this, wxID_ANY, wxT("&Add"), wxPoint(190, 121), wxDefaultSize);
btnAdd->SetDefault();
btnDelete = new wxButton(this, wxID_ANY, wxT("&Delete"), wxPoint(217, 121), wxDefaultSize);

// Connect event handlers
Connect(btnAdd->GetId(), wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler(FbDialog::OnAdd));
Connect(btnDelete->GetId(), wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler(FbDialog::OnDelete));
Connect(wxID_ANY, wxEVT_CLOSE_WINDOW, wxCloseEventHandler(FbDialog::OnClose));
} // FbDialog constructor
}; // FbDialog class

// Derive application class
class FbApp : public wxApp {

public:
// Display user interface
bool OnInit() {
FbDialog *dlg = new FbDialog();
dlg->Show();
return true;
} // OnInit method
}; // FbApp class

// Define main entry point via compiler macro
IMPLEMENT_APP(FbApp)

// End of cwx_fruit.cpp

