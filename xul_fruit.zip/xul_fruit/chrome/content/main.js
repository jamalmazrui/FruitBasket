function doAdd(){
var txt = document.getElementById("txt_fruit");
var sFruit = txt.value;
if (sFruit == "") {
alert("No fruit to add!");
}
else {
var lst = document.getElementById("lst_basket");
lst.appendItem(sFruit, "");
txt.value = "";
var iCount = lst.getRowCount();
var iIndex = iCount - 1;
lst.selectedIndex = iIndex;
}
return false;
}

function doDelete(){
var lst = document.getElementById("lst_basket");
var iIndex = lst.selectedIndex;
if (iIndex == -1) {
alert("No fruit to delete!");
}
else {
lst.removeItemAt(iIndex);
var iCount = lst.getRowCount();
if (iIndex == iCount) {
iIndex = iCount - 1;
}
lst.selectedIndex = iIndex;
}
return false;
}

function doClose(){
if (confirm("Close program?")) {
return true;
}
else {
return false;
}
}
