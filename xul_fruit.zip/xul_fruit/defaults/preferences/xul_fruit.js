pref("toolkit.defaultChromeURI", "chrome://xul_fruit/content/main.xul");
