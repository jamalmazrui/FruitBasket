/*
content of jn_fruit.js
Fruit Basket program in JSscript .NET
Public domain by Jamal Mazrui
*/

import System;
import System.Drawing;
import System.Windows.Forms;

class FruitBasket extends Form {
var frm, lblFruit, txtFruit, lblBasket, lstBasket, btnAdd, btnDelete

function FruitBasket() {
this.SuspendLayout();
this.Text = "Fruit Basket";
this.AutoSize = true;
this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;

var flpMain = new FlowLayoutPanel();
flpMain.SuspendLayout();
flpMain.AutoSize = true;
flpMain.AutoSizeMode  = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
flpMain.FlowDirection = FlowDirection.TopDown;

var flpData = new FlowLayoutPanel();
flpData.SuspendLayout();
flpData.AutoSize = true;
flpData.AutoSizeMode  = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
flpData.FlowDirection = FlowDirection.LeftToRight;

lblFruit = new Label();
lblFruit.Text = "&Fruit:";

txtFruit = new TextBox();
txtFruit.AccessibleName = lblFruit.Text.Replace("&", "");

lblBasket = new Label();
lblBasket.Text = "&Basket:";

lstBasket = new ListBox();
lstBasket.AccessibleName = lblBasket.Text.Replace("&", "");

flpData.Controls.AddRange([lblFruit, txtFruit, lblBasket, lstBasket]);
flpData.ResumeLayout();

var flpButtons = new FlowLayoutPanel();
flpButtons.SuspendLayout();
flpButtons.Anchor = AnchorStyles.None;
flpButtons.AutoSize = true;
flpButtons.AutoSizeMode  = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
flpButtons.FlowDirection = FlowDirection.LeftToRight;

btnAdd = new Button();
btnAdd.Text = "&Add";
btnAdd.AccessibleName = btnAdd.Text.Replace("&", "");
btnAdd.add_Click(OnAddButtonClick);

btnDelete = new Button();
btnDelete.Text = "&Delete";
btnDelete.AccessibleName = btnDelete.Text.Replace("&", "");
btnDelete.add_Click(OnDeleteButtonClick);

flpButtons.Controls.AddRange([btnAdd, btnDelete]);
flpButtons.ResumeLayout();

flpMain.Controls.AddRange([flpData, flpButtons]);
flpMain.ResumeLayout();

this.Controls.Add(flpMain);
this.AcceptButton = btnAdd;
this.StartPosition = FormStartPosition.CenterScreen;
this.add_Closing(OnFruitBasketClosing);
this.ResumeLayout();
}

function OnAddButtonClick(sender : System.Object, e : System.EventArgs) { 
var sFruit = txtFruit.Text.Trim();
if (sFruit == "") {
MessageBox.Show("No fruit to add!", "Alert");
return;
}

lstBasket.Items.Insert(0, sFruit);
lstBasket.SelectedIndex = 0;
txtFruit.Clear();
}

function OnDeleteButtonClick(sender : System.Object, e : System.EventArgs) { 
var iIndex = lstBasket.SelectedIndex;
if (iIndex == -1) { 
MessageBox.Show("No fruit to delete!", "Alert");
return;
}

lstBasket.Items.RemoveAt(iIndex);
var iCount = lstBasket.Items.Count;
if (iIndex  < iCount) lstBasket.SelectedIndex = iIndex;
else if (iCount > 0) lstBasket.SelectedIndex = iCount - 1;
}

function OnFruitBasketClosing(sender : System.Object, e : System.ComponentModel.CancelEventArgs) { 
if (MessageBox.Show("Exit program?", "Confirm", MessageBoxButtons.OKCancel)
 == System.Windows.Forms.DialogResult.Cancel) e.Cancel = true;
}

}

Application.Run(new FruitBasket());

//End of program
