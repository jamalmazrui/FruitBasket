/*
Content of FruitBasket.java
Fruit basket program in Java with SWT
Public domain by Jamal Mazrui
*/

import org.eclipse.swt.*;
import org.eclipse.swt.events.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class FruitBasket {

public static int MB(Shell shell, String sMessage, String sText, int iStyle) {
MessageBox mb = new MessageBox(shell, iStyle);
mb.setMessage(sMessage);
mb.setText(sText);
return mb.open();
}

public static void main(String [] args) {
Display display = new Display();
final Shell shell = new Shell(display);
shell.setText("Fruit Basket");
RowLayout lytMain = new RowLayout(SWT.VERTICAL);
lytMain.marginLeft = lytMain.marginTop = lytMain.marginRight = lytMain.marginBottom = 14;
lytMain.justify = true;
lytMain.spacing = 6;
lytMain.wrap = false;
shell.setLayout(lytMain);

Composite cptData = new Composite(shell, SWT.NONE);
RowLayout lytData = new RowLayout(SWT.HORIZONTAL);
lytData.spacing = 6;
lytData.justify = true;
lytData.wrap = false;
cptData.setLayout(lytData);

Label lblFruit = new Label(cptData, SWT.NONE);
lblFruit.setText("&Fruit:");

final Text txtFruit = new Text(cptData, SWT.BORDER);

Label lblBasket = new Label(cptData, SWT.NONE);
lblBasket.setText("&Basket:");

final List lstBasket = new List(cptData, SWT.BORDER | SWT.V_SCROLL);

Composite cptButtons = new Composite(shell, SWT.NONE);
RowLayout lytButtons = new RowLayout(SWT.HORIZONTAL);
lytButtons.spacing = 6;
lytButtons.justify = true;
lytButtons.wrap = false;
cptButtons.setLayout(lytButtons);

Button btnAdd = new Button(cptButtons, SWT.PUSH);
btnAdd.setText("&Add");

btnAdd.addSelectionListener(new SelectionAdapter() {
public void widgetSelected(SelectionEvent e) {
String sFruit = txtFruit.getText().trim();
if(sFruit == "") {
MB(shell, "No fruit to add!", "Alert", SWT.OK);
}
else {
lstBasket.add(sFruit, 0);
lstBasket.select(0);
txtFruit.setText("");
}
txtFruit.setFocus();
}
});

shell.setDefaultButton(btnAdd);

Button btnDelete = new Button(cptButtons, SWT.PUSH);
btnDelete.setText("&Delete");

btnDelete.addSelectionListener(new SelectionAdapter() {
public void widgetSelected(SelectionEvent e) {
int iIndex = lstBasket.getSelectionIndex();
if(iIndex == -1) {
MB(shell, "No fruit to delete!", "Alert", SWT.OK);
}
else {
lstBasket.remove(iIndex);
int iCount = lstBasket.getItemCount();
if(iIndex > iCount - 1) iIndex = iCount - 1;
lstBasket.select(iIndex);
}
lstBasket.setFocus();
}
});

shell.addShellListener(new ShellAdapter() {
public void shellClosed(ShellEvent e) {
if(MB(shell, "Exit program?", "Confirm", SWT.YES | SWT.NO | SWT.CANCEL) != SWT.YES) e.doit = false;
}
});

shell.open();
while(!shell.isDisposed()) {
if(!display.readAndDispatch()) display.sleep();
}
display.dispose();
}
}

//End of program
