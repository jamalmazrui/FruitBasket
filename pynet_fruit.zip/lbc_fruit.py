"""
Fruit Basket program in Python.NET
Public domain by Jamal Mazrui
May 4, 2010
"""

# Import namespaces
import clr
clr.AddReference('HomerLbc')
from Homer import *
import pythoncom
pythoncom.CoInitialize()

def OnEvent(oSender, oArgs):
	if oSender == dlg: sEvent = 'Closing'
	else: sEvent = 'Click'
	
	txtFruit = dlg.GetTextBox('Fruit')
	lstBasket = dlg.GetListBox('Basket')
	if sEvent == 'Closing':
		if Lbc.DialogConfirm('Confirm', 'Exit program?', 'Y') != 'Y': oArgs.Cancel = True
	elif sEvent == 'Click':
		if oSender.Name == 'Button_Add':
			sFruit = txtFruit.Text
			if not sFruit: return Lbc.DialogShow('Alert', 'No fruit to add!')

			lstBasket.Items.Add(sFruit)
			iIndex = lstBasket.Items.Count - 1
			lstBasket.SelectedIndex = iIndex
			txtFruit.Clear()
		elif oSender.Name == 'Button_Delete':
			iIndex = lstBasket.SelectedIndex
			if iIndex == -1: return Lbc.DialogShow('Alert', 'No fruit to delete!')

			lstBasket.Items.RemoveAt(iIndex)
			iCount = lstBasket.Items.Count
			if not iCount: return
			if iIndex == iCount: iIndex -= 1
			lstBasket.SelectedIndex = iIndex
	# OnEvent function


dlg = LbcForm('Fruit Basket')
dlg.AddInputBox('Fruit')
btnAdd = dlg.AddButton('Add')
btnAdd.Click += OnEvent
dlg.AcceptButton = btnAdd
dlg.AddBand()
dlg.AddPickBox('Basket')
btnDelete = dlg.AddButton('Delete')
btnDelete.Click += OnEvent
dlg.Closing += OnEvent
dlg.CompleteDialog()

