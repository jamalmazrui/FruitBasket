"""
Fruit Basket program in Python.NET
Public domain by Jamal Mazrui
April 11, 2009
"""

# Import namespaces
import clr
from System.Windows.Forms import *

# Define Add event handler
def HandleAdd(sender, event):
	sFruit = txtFruit.Text
	if len(sFruit) == 0: return MessageBox.Show('No fruit to add!', 'Alert')
	lstBasket.Items.Add(sFruit)
	txtFruit.Clear()
	lstBasket.SelectedIndex = lstBasket.Items.Count - 1
	
# Define Delete event handler
def HandleDelete(sender, event):
	iFruit = lstBasket.SelectedIndex
	if iFruit == -1: return MessageBox.Show('No fruit to delete.', 'Alert')
	lstBasket.Items.RemoveAt(iFruit)
	if iFruit == lstBasket.Items.Count: iFruit -= 1
	if iFruit >= 0: lstBasket.SelectedIndex = iFruit
	
# Create controls
lblFruit = Label()
lblFruit.Text='&Fruit:'

txtFruit = TextBox()

btnAdd = Button()
btnAdd.Text='&Add'
btnAdd.Click += HandleAdd

lblBasket = Label()
lblBasket.Text='&Basket:'

lstBasket = ListBox()

btnDelete = Button()
btnDelete.Text='&Delete'
btnDelete.Click += HandleDelete

tlp = TableLayoutPanel()
tlp.ColumnCount=3
tlp.RowCount=2
tlp.Controls.AddRange((lblFruit, txtFruit, btnAdd, lblBasket, lstBasket, btnDelete))

# Finalize dialog
dlg = Form()
dlg.Text='Fruit Basket'
dlg.AcceptButton=btnAdd
dlg.StartPosition=FormStartPosition.CenterScreen
dlg.AutoSize=True
dlg.AutoSizeMode=AutoSizeMode.GrowAndShrink
dlg.Controls.Add(tlp)
dlg.ShowDialog()
