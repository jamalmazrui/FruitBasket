/*
content of vj_fruit.java
Fruit Basket program in Visual J#
Public domain by Jamal Mazrui
*/

import System.*;
import System.ComponentModel.*;
import System.Drawing.*;
import System.Windows.Forms.*;

class FruitBasket extends Form {
Label lblFruit, lblBasket;
TextBox txtFruit;
ListBox lstBasket;
Button btnAdd, btnDelete;

FruitBasket() {
this.SuspendLayout();
this.set_Text("Fruit Basket");
this.set_Text("Fruit Basket");
this.set_AutoSize(true);
this.set_AutoSizeMode(AutoSizeMode.GrowAndShrink);

FlowLayoutPanel flpMain = new FlowLayoutPanel();
flpMain.SuspendLayout();
flpMain.set_AutoSize(true);
flpMain.set_AutoSizeMode(AutoSizeMode.GrowAndShrink);
flpMain.set_FlowDirection(FlowDirection.TopDown);

FlowLayoutPanel flpData = new FlowLayoutPanel();
flpData.SuspendLayout();
flpData.set_AutoSize(true);
flpData.set_AutoSizeMode(AutoSizeMode.GrowAndShrink);
flpData.set_FlowDirection(FlowDirection.LeftToRight);

lblFruit = new Label();
lblFruit.set_Text("&Fruit:");

txtFruit = new TextBox();
txtFruit.set_AccessibleName(lblFruit.get_Text().Replace("&", ""));

lblBasket = new Label();
lblBasket.set_Text("&Basket:");

lstBasket = new ListBox();
lstBasket.set_AccessibleName(lblBasket.get_Text().Replace("&", ""));

flpData.get_Controls().AddRange(new Control[] {lblFruit, txtFruit, lblBasket, lstBasket});
flpData.ResumeLayout();

FlowLayoutPanel flpButtons = new FlowLayoutPanel();
flpButtons.SuspendLayout();
flpButtons.set_Anchor(AnchorStyles.None);
flpButtons.set_AutoSize(true);
flpButtons.set_AutoSizeMode(AutoSizeMode.GrowAndShrink);
flpButtons.set_FlowDirection(FlowDirection.LeftToRight);

btnAdd = new Button();
btnAdd.set_Text("&Add");
btnAdd.set_AccessibleName(btnAdd.get_Text().Replace("&", ""));
btnAdd.add_Click(new EventHandler(OnAddButtonClick));

btnDelete = new Button();
btnDelete.set_Text("&Delete");
btnDelete.set_AccessibleName(btnDelete.get_Text().Replace("&", ""));
btnDelete.add_Click(new EventHandler(OnDeleteButtonClick));

flpButtons.get_Controls().AddRange( new Control[] {btnAdd, btnDelete});
flpButtons.ResumeLayout();

flpMain.get_Controls().AddRange( new Control[] {flpData, flpButtons});
flpMain.ResumeLayout();

this.get_Controls().Add(flpMain);
this.set_AcceptButton(btnAdd);
this.set_StartPosition(FormStartPosition.CenterScreen);
this.add_Closing(new CancelEventHandler(OnFruitBasketClosing));
this.ResumeLayout();
}

void OnAddButtonClick(Object sender, EventArgs e) { 
String sFruit = txtFruit.get_Text().Trim();
if (sFruit.get_Length() == 0) {
MessageBox.Show("No fruit to add!", "Alert");
return;
}

lstBasket.get_Items().Insert(0, sFruit);
lstBasket.set_SelectedIndex(0);
txtFruit.Clear();
}

void OnDeleteButtonClick(Object sender, EventArgs e) { 
int iIndex = lstBasket.get_SelectedIndex();
if (iIndex == -1) { 
MessageBox.Show("No fruit to delete!", "Alert");
return;
}

lstBasket.get_Items().RemoveAt(iIndex);
int iCount = lstBasket.get_Items().get_Count();
if (iIndex  < iCount) lstBasket.set_SelectedIndex(iIndex);
else if (iCount > 0) lstBasket.set_SelectedIndex(iCount - 1);
}

void OnFruitBasketClosing(Object sender, CancelEventArgs e) { 
if (MessageBox.Show("Exit program?", "Confirm", MessageBoxButtons.OKCancel)
 == DialogResult.Cancel) e.set_Cancel(true);
}

public static void main() {
Application.Run(new FruitBasket());
}

}

//End of program
