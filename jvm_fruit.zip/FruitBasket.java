/*
Content of FruitBasket.java
Fruit basket program in Java with SWT
Public domain by Jamal Mazrui
September 6, 2010
*/

import org.eclipse.swt.*;
import org.eclipse.swt.events.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

class FruitBasket {

public static void main(String[] args) {
Display display = new Display();
final Shell shell = new Shell(display);
shell.setText("Fruit Basket");

GridLayout lytGrid = new GridLayout();
lytGrid.numColumns = 3;
shell.setLayout(lytGrid);

Label lblFruit = new Label(shell, SWT.NONE);
lblFruit.setText("&Fruit:");

final Text txtFruit = new Text(shell, SWT.BORDER);

Button btnAdd = new Button(shell, SWT.PUSH);
btnAdd.setText("&Add");
shell.setDefaultButton(btnAdd);

Label lblBasket = new Label(shell, SWT.NONE);
lblBasket.setText("&Basket:");

final List lstBasket = new List(shell, SWT.BORDER | SWT.V_SCROLL);

Button btnDelete = new Button(shell, SWT.PUSH);
btnDelete.setText("&Delete");

btnAdd.addSelectionListener(new SelectionAdapter() {
public void widgetSelected(SelectionEvent e) {
String sFruit = txtFruit.getText().trim();
if (sFruit == "") {
ShowMessage(shell, "No fruit to add!", "Alert", SWT.OK);
}
else {
lstBasket.add(sFruit, 0);
lstBasket.select(0);
txtFruit.setText("");
}
txtFruit.setFocus();
}
});

btnDelete.addSelectionListener(new SelectionAdapter() {
public void widgetSelected(SelectionEvent e) {
int iIndex = lstBasket.getSelectionIndex();
if (iIndex == -1) {
ShowMessage(shell, "No fruit to delete!", "Alert", SWT.OK);
}
else {
lstBasket.remove(iIndex);
int iCount = lstBasket.getItemCount();
if (iIndex > iCount - 1) iIndex = iCount - 1;
lstBasket.select(iIndex);
}
lstBasket.setFocus();
}
});

shell.addShellListener(new ShellAdapter() {
public void shellClosed(ShellEvent e) {
if (ShowMessage(shell, "Exit program?", "Confirm", SWT.YES | SWT.NO | SWT.CANCEL) != SWT.YES) e.doit = false;
}
});

shell.pack();
shell.open();
while(!shell.isDisposed()) {
if (!display.readAndDispatch()) display.sleep();
}
display.dispose();
} // main method

static int ShowMessage(Shell shell, String sMessage, String sText, int iStyle) {
MessageBox mb = new MessageBox(shell, iStyle);
mb.setMessage(sMessage);
mb.setText(sText);
return mb.open();
} // showMessage method
} // FruitBasket class
