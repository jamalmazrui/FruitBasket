/*
Content of FruitBasket.rb
Fruit basket program in JRuby with SWT
Public domain by Jamal Mazrui
September 6, 2010
*/

module FB
require 'java'
require 'swt.jar'
include_package 'org.eclipse.swt'
include_package 'org.eclipse.swt.events'
include_package 'org.eclipse.swt.graphics'
include_package 'org.eclipse.swt.layout'
include_package 'org.eclipse.swt.widgets'

def showMessage(shell, sMessage, sText, iStyle)
mb = MessageBox.new(shell, iStyle)
mb.message = sMessage
mb.text = sText
return mb.open
end # showMessage method
end # FB module

include FB
module FB
display = Display.new
shell = Shell.new(display)
shell.text = "Fruit Basket"
lytGrid = GridLayout.new
lytGrid.numColumns = 3
shell.layout = lytGrid

lblFruit = Label.new(shell, SWT::NONE)
lblFruit.text = "&Fruit:"

txtFruit = Text.new(shell, SWT::BORDER)

btnAdd = Button.new(shell, SWT::PUSH)
btnAdd.text = "&Add"
shell.defaultButton = btnAdd

lblBasket = Label.new(shell, SWT::NONE)
lblBasket.text = "&Basket:"

lstBasket = List.new(shell, SWT::BORDER | SWT::V_SCROLL)

btnDelete = Button.new(shell, SWT::PUSH)
btnDelete.text = "&Delete"

btnAdd.addSelectionListener do
sFruit = txtFruit.text.strip
if sFruit == ""
showMessage(shell, "No fruit to add!", "Alert", SWT::OK)
else
lstBasket.add(sFruit, 0)
lstBasket.select(0)
txtFruit.text = ""
end # if
txtFruit.setFocus
end # do

btnDelete.addSelectionListener do
iIndex = lstBasket.selectionIndex
if iIndex == -1
showMessage(shell, "No fruit to delete!", "Alert", SWT::OK)
else
lstBasket.remove(iIndex)
iCount = lstBasket.itemCount
iIndex = iCount - 1 if iIndex > iCount - 1 
lstBasket.select(iIndex)
end # if
lstBasket.setFocus
end # do

class ClosedEvent < ShellAdapter
def initialize(shell)
@shell = shell
super()
end # initialize method

def shellClosed(e)
e.doit = false if showMessage(@shell, "Exit program?", "Confirm", SWT::YES | SWT::NO | SWT::CANCEL) != SWT::YES
end # shellClosed methodd
end # ClosedEvent class

shell.addShellListener ClosedEvent.new(shell)

shell.pack
shell.open

display.sleep unless display.readAndDispatch while !shell.isDisposed
display.dispose
end # FB module
