/*
Content of FruitBasket.groovy
Fruit basket program in Groovy with SWT
Public domain by Jamal Mazrui
September 6, 2010
*/

import org.eclipse.swt.*
import org.eclipse.swt.events.*
import org.eclipse.swt.graphics.*
import org.eclipse.swt.layout.*
import org.eclipse.swt.widgets.*

class FruitBasket {

static void main(args) {
def display = new Display()
def shell = new Shell(display)
shell.text = "Fruit Basket"

def lytGrid = new GridLayout()
lytGrid.numColumns = 3
shell.layout = lytGrid

def lblFruit = new Label(shell, SWT.NONE)
lblFruit.text = "&Fruit:"

def txtFruit = new Text(shell, SWT.BORDER)

def btnAdd = new Button(shell, SWT.PUSH)
btnAdd.text = "&Add"
shell.defaultButton = btnAdd

def lblBasket = new Label(shell, SWT.NONE)
lblBasket.text = "&Basket:"

def lstBasket = new List(shell, SWT.BORDER | SWT.V_SCROLL)

def btnDelete = new Button(shell, SWT.PUSH)
btnDelete.text = "&Delete"

btnAdd.addSelectionListener(new SelectionAdapter() {
void widgetSelected(SelectionEvent e) {
def sFruit = txtFruit.text.trim()
if(sFruit == "") {
ShowMessage(shell, "No fruit to add!", "Alert", SWT.OK)
}
else {
lstBasket.add(sFruit, 0)
lstBasket.select(0)
txtFruit.text = ""
}
txtFruit.setFocus()
}
})

btnDelete.addSelectionListener(new SelectionAdapter() {
void widgetSelected(SelectionEvent e) {
def iIndex = lstBasket.selectionIndex
if(iIndex == -1) {
ShowMessage(shell, "No fruit to delete!", "Alert", SWT.OK)
}
else {
lstBasket.remove(iIndex)
def iCount = lstBasket.itemCount
if(iIndex > iCount - 1) iIndex = iCount - 1
lstBasket.select(iIndex)
}
lstBasket.setFocus()
}
})

shell.addShellListener(new ShellAdapter() {
void shellClosed(ShellEvent e) {
if(ShowMessage(shell, "Exit program?", "Confirm", SWT.YES | SWT.NO | SWT.CANCEL) != SWT.YES) e.doit = false
}
})

shell.pack()
shell.open()
while(!shell.isDisposed()) {
if(!display.readAndDispatch()) display.sleep()
}
display.dispose()
} // main method

static int ShowMessage(shell, sMessage, sText, iStyle) {
def mb = new MessageBox(shell, iStyle)
mb.message = sMessage
mb.text = sText
return mb.open()
} // showMessage method
} // FruitBasket class
