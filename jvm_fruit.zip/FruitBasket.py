"""
Content of FruitBasket.py
Fruit basket program in Jython with SWT
Public domain by Jamal Mazrui
September 30, 2010
"""

from org.eclipse.swt import *
from org.eclipse.swt.events import *
from org.eclipse.swt.graphics import *
from org.eclipse.swt.layout import *
from org.eclipse.swt.widgets import *

def showMessage(shell, sMessage, sText, iStyle):
	mb = MessageBox(shell, iStyle, message=sMessage, text=sText)
	return mb.open()
# showMessage method

def addFruit(e):
	sFruit = txtFruit.text.strip()
	if not sFruit: showMessage(shell, 'No fruit to add!', 'Alert', SWT.OK)
	else:
		lstBasket.add(sFruit, 0)
		lstBasket.select(0)
		txtFruit.text = ''

	txtFruit.setFocus()
# addFruit method

def deleteFruit(e):
	iIndex = lstBasket.selectionIndex
	if iIndex == -1: showMessage(shell, 'No fruit to delete!', 'Alert', SWT.OK)
	else:
		lstBasket.remove(iIndex)
		iCount = lstBasket.itemCount
		if iIndex > iCount - 1: iIndex = iCount - 1
		lstBasket.select(iIndex)

	lstBasket.setFocus()
# deleteFruit method

def exitProgram(e):
	if showMessage(shell, 'Exit program?', 'Confirm', SWT.YES | SWT.NO | SWT.CANCEL) != SWT.YES: e.doit = False
# exitProgram method

display = Display()
shell = Shell(display, text='Fruit Basket', shellClosed=exitProgram)
lytGrid = GridLayout(numColumns=3)
shell.setLayout(lytGrid)

lblFruit = Label(shell, SWT.NONE, text='&Fruit:')
txtFruit = Text(shell, SWT.BORDER)
btnAdd = Button(shell, SWT.PUSH, text='&Add', widgetSelected=addFruit)
shell.defaultButton = btnAdd

lblBasket = Label(shell, SWT.NONE, text='&Basket:')
lstBasket = List(shell, SWT.BORDER | SWT.V_SCROLL)
btnDelete = Button(shell, SWT.PUSH, text='&Delete', widgetSelected=deleteFruit)

shell.pack()
shell.open()

while not shell.isDisposed():
	if not display.readAndDispatch(): display.sleep()

display.dispose()
