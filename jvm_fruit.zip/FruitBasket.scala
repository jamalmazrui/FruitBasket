/*
Content of FruitBasket.scala
Fruit basket program in Scala with SWT
Public domain by Jamal Mazrui
September 6, 2010
*/

import org.eclipse.swt._
import org.eclipse.swt.events._
import org.eclipse.swt.graphics._
import org.eclipse.swt.layout._
import org.eclipse.swt.widgets._

object FruitBasket extends Application {
val display = new Display()
val shell = new Shell(display)
shell.setText("Fruit Basket")

val lytGrid = new GridLayout()
lytGrid.numColumns = 3
shell.setLayout(lytGrid)

val lblFruit = new Label(shell, SWT.NONE)
lblFruit.setText("&Fruit:")

val txtFruit = new Text(shell, SWT.BORDER)

val btnAdd = new Button(shell, SWT.PUSH)
btnAdd.setText("&Add")
shell.setDefaultButton(btnAdd)

val lblBasket = new Label(shell, SWT.NONE)
lblBasket.setText("&Basket:")

val lstBasket = new List(shell, SWT.BORDER | SWT.V_SCROLL)

val btnDelete = new Button(shell, SWT.PUSH)
btnDelete.setText("&Delete")

btnAdd.addSelectionListener(new SelectionAdapter() {
override def widgetSelected(e: SelectionEvent) = {
val sFruit = txtFruit.getText().trim()
if(sFruit == "") {
ShowMessage(shell, "No fruit to add!", "Alert", SWT.OK)
}
else {
lstBasket.add(sFruit, 0)
lstBasket.select(0)
txtFruit.setText("")
}
txtFruit.setFocus()
}
})

btnDelete.addSelectionListener(new SelectionAdapter() {
override def widgetSelected(e: SelectionEvent) = {
var iIndex = lstBasket.getSelectionIndex()
if(iIndex == -1) {
ShowMessage(shell, "No fruit to delete!", "Alert", SWT.OK)
}
else {
lstBasket.remove(iIndex)
val iCount = lstBasket.getItemCount()
if(iIndex > iCount - 1) iIndex = iCount - 1
lstBasket.select(iIndex)
}
lstBasket.setFocus()
}
})

shell.addShellListener(new ShellAdapter() {
override def shellClosed(e: ShellEvent) = {
if(ShowMessage(shell, "Exit program?", "Confirm", SWT.YES | SWT.NO | SWT.CANCEL) != SWT.YES) e.doit = false
}
})

shell.pack()
shell.open()
while(!shell.isDisposed()) {
if(!display.readAndDispatch()) display.sleep()
}
display.dispose()

def ShowMessage(shell: Shell, sMessage: String, sText : String, iStyle: Int): Int = {
val mb = new MessageBox(shell, iStyle)
mb.setMessage(sMessage)
mb.setText(sText)
return mb.open
} // showMessage method
} // FruitBasket class


