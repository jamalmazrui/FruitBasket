/*
content of wpf_fruit.cs
Fruit Basket program in C# 4.0 with Windows Presentation Foundation
Public domain by Jamal Mazrui
June 8, 2010
*/

// Import namespaces
using System;
using System.Windows;
using System.Windows.Controls;

// Define class
class FruitBasket: Application {

// Define entry point of program
[STAThread]
static void Main() {
// Create controls;
var txtFruit = new TextBox();
var lblFruit = new Label {Content = "_Fruit:", Target = txtFruit};
var btnAdd = new Button {Content = "_Add", IsDefault = true};
var lstBasket = new ListBox();
    var lblBasket = new Label {Content = "_Basket:", Target = lstBasket};
var btnDelete = new Button {Content = "_Delete"};

// Define Add event handler;
btnAdd.Click += (o, e) => {
var sFruit = txtFruit.Text.Trim();
if (sFruit == "") MessageBox.Show("No fruit to add!", "Alert");
else {
lstBasket.Items.Add(sFruit);
txtFruit.Clear();
lstBasket.SelectedIndex = lstBasket.Items.Count - 1;
}
};

// Define Delete event handler;
btnDelete.Click += (o,e) => {
var iFruit = lstBasket.SelectedIndex;
if (iFruit == -1) MessageBox.Show("No fruit to delete!", "Alert");
else {
lstBasket.Items.RemoveAt(iFruit);
if (iFruit == lstBasket.Items.Count) iFruit--;
lstBasket.SelectedIndex = iFruit;
}
};

// Complete layout
Window dlg;
var bUseGrid = false;
bUseGrid = true;
if (bUseGrid) {
var grid = new Grid();
grid.ColumnDefinitions.Clear();
// for (var i = 0; i < 3; i++) grid.ColumnDefinitions.Add(new ColumnDefinition {Width = new GridLength(1, GridUnitType.Auto)});
for (var i = 0; i < 3; i++) grid.ColumnDefinitions.Add(new ColumnDefinition {Width = new GridLength(2, GridUnitType.Auto)});

grid.RowDefinitions.Clear();
// for (var i = 0; i < 2; i++) grid.RowDefinitions.Add(new RowDefinition {Height = new GridLength(1, GridUnitType.Auto)});
for (var i = 0; i < 2; i++) grid.RowDefinitions.Add(new RowDefinition {Height = new GridLength(2, GridUnitType.Auto)});

foreach (var widget in new UIElement[] {lblFruit, txtFruit, btnAdd, lblBasket, lstBasket, btnDelete}) grid.Children.Add(widget);

Grid.SetColumn(lblFruit, 0);
Grid.SetRow(lblFruit, 0);
Grid.SetColumn(txtFruit, 1);
Grid.SetRow(txtFruit, 0);
Grid.SetColumn(btnAdd, 2);
Grid.SetRow(btnAdd, 0);
Grid.SetColumn(lblBasket, 0);
Grid.SetRow(lblBasket, 1);
Grid.SetColumn(lstBasket, 1);
Grid.SetRow(lstBasket, 1);
Grid.SetColumn(btnDelete, 2);
Grid.SetRow(btnDelete, 1);

dlg = new Window {Title = "Fruit Basket", Content = grid, SizeToContent = SizeToContent.WidthAndHeight, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center};
// dlg = new Window {Title = "Fruit Basket", Content = grid, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center};
}
else {
var panelAdd = new StackPanel {Orientation = Orientation.Horizontal};
foreach (var widget in new UIElement[] {lblFruit, txtFruit, btnAdd}) panelAdd.Children.Add(widget);

var panelDelete = new StackPanel {Orientation = Orientation.Horizontal};
foreach (var widget in new UIElement[] {lblBasket, lstBasket, btnDelete}) panelDelete.Children.Add(widget);

var panelMain = new StackPanel {Orientation = Orientation.Vertical};
foreach (var widget in new UIElement[] {panelAdd, panelDelete}) panelMain.Children.Add(widget);

dlg = new Window {Title = "Fruit Basket", Content = panelMain, SizeToContent = SizeToContent.WidthAndHeight, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center};
}

// Define closing event handler
dlg.Closing += (o, e) => e.Cancel = (MessageBox.Show("Close program?", "Confirm", MessageBoxButton.YesNo) == MessageBoxResult.No);

// Finalize dialog
txtFruit.Focus();

var bUseApplication = true;
// bUseApplication = false;
if (bUseApplication) {
var app = new FruitBasket();
app.Run(dlg);
}
else dlg.ShowDialog();
} // Main method
} // FruitBasket class

// End of wpf_fruit.cs
