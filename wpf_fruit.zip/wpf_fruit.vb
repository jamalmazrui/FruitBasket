'content of wpf_fruit.vb
'Fruit Basket program in Visual Basic 10 with Windows Presentation Foundation
'Public domain by Jamal Mazrui
'June 8, 2010

Option Explicit On
Option Strict On

' Import namespaces
Imports System.Windows
Imports System.Windows.Controls

' Define class
Class FruitBasket
Inherits Application

' Define entry point of program
<STAThread> Shared Sub Main()

' Create controls;
Dim txtFruit = New TextBox()
Dim lblFruit = New Label With {.Content = "_Fruit:", .Target = txtFruit }
Dim btnAdd = New Button With { .Content = "_Add", .IsDefault = True }
Dim lstBasket = New ListBox()
Dim lblBasket = New Label With { .Content = "_Basket:", .Target = lstBasket }
Dim btnDelete = New Button With { .Content = "_Delete" }

' Define Add event handler;
AddHandler btnAdd.Click, Sub()
Dim sFruit = txtFruit.Text.Trim()
If sFruit = "" Then
MessageBox.Show("No fruit to add!", "Alert")
Else
lstBasket.Items.Add(sFruit)
txtFruit.Clear()
lstBasket.SelectedIndex = lstBasket.Items.Count - 1
End If
End Sub

' Define Delete event handler;
AddHandler btnDelete.Click, Sub()
Dim iFruit = lstBasket.SelectedIndex
If iFruit = -1 Then
MessageBox.Show("No fruit to delete!", "Alert")
Else
lstBasket.Items.RemoveAt(iFruit)
If iFruit = lstBasket.Items.Count Then iFruit -= 1
lstBasket.SelectedIndex = iFruit
End If
End Sub

' Complete layout
Dim dlg As Window
Dim bUseGrid = True
' bUseGrid = false;
If bUseGrid Then
Dim grid = New Grid()
grid.ColumnDefinitions.Clear()
For i = 0 To 2
grid.ColumnDefinitions.Add(New ColumnDefinition With { .Width = New GridLength(1, GridUnitType.Auto) })
Next

grid.RowDefinitions.Clear()
For i = 0 To 1
grid.RowDefinitions.Add(New RowDefinition With { .Height = New GridLength(1, GridUnitType.Auto) })
Next

For Each widget In New UIElement() {lblFruit, txtFruit, btnAdd, lblBasket, lstBasket, btnDelete}
grid.Children.Add(widget)
Next

dlg = New Window With { .Title =
"Fruit Basket", .Content = grid, .SizeToContent = SizeToContent.WidthAndHeight, .HorizontalAlignment = HorizontalAlignment.Center, .VerticalAlignment = VerticalAlignment.Center }
Else
Dim panelAdd = New StackPanel With { .Orientation = Orientation.Horizontal }
For Each widget In New UIElement() {lblFruit, txtFruit, btnAdd}
panelAdd.Children.Add(widget)
Next

Dim panelDelete = New StackPanel With {.Orientation = Orientation.Horizontal}
For Each widget In New UIElement() {lblBasket, lstBasket, btnDelete}
panelDelete.Children.Add(widget)
Next

Dim panelMain = New StackPanel With {.Orientation = Orientation.Vertical}
For Each widget In New UIElement() {panelAdd, panelDelete}
panelMain.Children.Add(widget)
Next

dlg = New Window With {.Title = "Fruit Basket", .Content = panelMain, .SizeToContent = SizeToContent.WidthAndHeight, .HorizontalAlignment = HorizontalAlignment.Center, .VerticalAlignment = VerticalAlignment.Center}
End If

' Define closing event handler
AddHandler dlg.Closing, Sub(o, e)
If MessageBox.Show("Close program?", "Confirm", MessageBoxButton.YesNo) = MessageBoxResult.No Then e.Cancel = True
End Sub

' Finalize dialog
txtFruit.Focus()

Dim bUseApplication = True
' bUseApplication = false
If bUseApplication Then
Dim app = New FruitBasket()
app.Run(dlg)
Else
dlg.ShowDialog()
End If
End Sub
End Class
' End of wpf_fruit.vb
