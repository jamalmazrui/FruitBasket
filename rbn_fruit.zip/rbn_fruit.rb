# content of rbn_fruit.rb
# Fruit Basket program in Ruby.NET
# Public domain by Jamal Mazrui

# Reference libraries
["mscorlib.dll", "System.dll", "System.Windows.Forms.dll"].each {|dll| require(dll)}

# Import namespace
include System::Windows::Forms
 
# Create controls
tlp = TableLayoutPanel.new
tlp.ColumnCount = 3
tlp.RowCount = 2

lblFruit =  Label.new
lblFruit.Text = "&Fruit:"

txtFruit =  TextBox.new

btnAdd =  Button.new
btnAdd.Text = "&Add"

lblBasket =  Label.new
lblBasket.Text = "&Basket:"

lstBasket =  ListBox.new

btnDelete =  Button.new
btnDelete.Text = "&Delete"

[lblFruit, txtFruit, btnAdd, lblBasket, lstBasket, btnDelete].each {|ctl| tlp.Controls.Add(ctl)}

# Define Add event handler
btnAdd.add_Click do
sFruit = txtFruit.Text.Trim
if sFruit.Length == 0
 MessageBox.Show("No fruit to add!", "Alert") 
else
lstBasket.Items.Add(sFruit)
txtFruit.Clear
iFruit = lstBasket.Items.Count - 1
lstBasket.SelectedIndex = iFruit
end
end

# Define Delete event handler
btnDelete.add_Click do
iFruit = lstBasket.SelectedIndex
if iFruit == -1
 MessageBox.Show("No fruit to delete!", "Alert") 
else
lstBasket.Items.RemoveAt(iFruit)
iFruit -= 1 if iFruit = lstBasket.Items.Count
lstBasket.SelectedIndex = iFruit
end
end

# Finalize dialog
dlg =  Form.new
dlg.Text = "Fruit Basket"
dlg.AcceptButton = btnAdd
dlg.StartPosition =  FormStartPosition.CenterScreen
dlg.AutoSize = true
dlg.AutoSizeMode =  AutoSizeMode.GrowAndShrink
dlg.Controls.Add(tlp)
dlg.ShowDialog

# End of rbn_fruit.rb

