/*
content of cs_fruit.cs
Fruit Basket program in C#
Public domain by Jamal Mazrui
*/

namespace FruitBasket {
using System;
using System.Windows.Forms;

// define class inherited from Form
class FbForm : Form {
Label lblFruit;
TextBox txtFruit;
Label lblBasket;
ListBox lstBasket;
Button btnAdd;
Button btnDelete;

// define constructor
public FbForm() {
// set window title
this.Text = "Fruit Basket";

this.Width = 400;
this.Height = 285;

// create two rows of controls with three controls in each row
// label, textbox, button and label, listbox, button
lblFruit = new Label();
lblFruit.Text = "&Fruit:";
lblFruit.Left = 14;
lblFruit.Top = 14;
lblFruit.Width = 44;
lblFruit.Height = 16;

txtFruit = new TextBox();
txtFruit.Left = 64;
txtFruit.Top = 14;
txtFruit.Width = 200;
txtFruit.Height = 16;

btnAdd = new Button();
btnAdd.Text = "&Add";
btnAdd.Left = 272;
btnAdd.Top = 14;
btnAdd.Width = 100;
btnAdd.Height = 20;
//  make it the default button
this.AcceptButton = btnAdd;

// Define event handler
btnAdd.Click += delegate(object o, EventArgs e) {
string sFruit = txtFruit.Text;
if (sFruit == "") {
MessageBox.Show("No fruit to add!", "Alert");
return;
}

lstBasket.Items.Add(sFruit);
txtFruit.Text = "";
lstBasket.SelectedIndex = lstBasket.Items.Count - 1;
};

lblBasket = new Label();
lblBasket.Text = "&Basket:";
lblBasket.Left = 14;
lblBasket.Top = 38;
lblBasket.Width = 44;
lblBasket.Height = 16;

lstBasket = new ListBox();
lstBasket.Left = 64;
lstBasket.Top = 38;
lstBasket.Width = 200;
lstBasket.Height = 200;

btnDelete = new Button();
btnDelete.Text = "&Delete";
btnDelete.Left = 272;
btnDelete.Top = 38;
btnDelete.Width = 100;
btnDelete.Height = 20;

// Define event handler
btnDelete.Click += delegate(object o, EventArgs e) {
int iFruit = lstBasket.SelectedIndex;
if (iFruit == -1) {
MessageBox.Show("No fruit to delete.", "Alert");
return;
}

lstBasket.Items.RemoveAt(iFruit);
if (iFruit > lstBasket.Items.Count - 1) {iFruit = lstBasket.Items.Count - 1;}
lstBasket.SelectedIndex = iFruit;
};

// add controls to form
this.Controls.AddRange( new Control[] {lblFruit, txtFruit, btnAdd, lblBasket, lstBasket, btnDelete});

// center form on screen
this.StartPosition = FormStartPosition.CenterScreen;
} // FbForm constructor

// define main entry point of application
static void Main() {
Application.Run(new FbForm());
} // Main method
} // FbForm class
} // FruitBasket namespace
