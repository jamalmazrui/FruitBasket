Layout by Code
AutoIt implementation
Version 2.4
October 21, 2015
Copyright 2006 - 2015 by Jamal Mazrui
GNU Lesser General Public License (LGPL)Layout by Code (LbC) is an approach to designing graphical user interfaces via specialized routines rather than graphical layout tools.  Those tools tend to be visually and mouse oriented, and thus challenging for blind programmers to use reliably and efficiently. The original implementation of LbC is in the programming language called AutoIt -- a Basic-like language with a free interpreter and compiler -- available from
www.AutoItScript.com

The file LbC.au3, included in this project, is a function library that may be included in an AutoIt program.  Full documentation is in the file Lbc.htm.
