#Public domain by Jamal Mazrui
# Initial settings
use strict;
use warnings;
use Wx ;
use Wx qw(:everything);

# Custom dialog class
package MyDialog;
use base 'Wx::Dialog';
use Wx qw(:everything);
use Wx::Event qw(EVT_BUTTON EVT_MENU EVT_CLOSE EVT_SIZE EVT_UPDATE_UI);

my ($FruitInput, $BasketList);

sub new {
my $class = shift;
#
my $dialog = $class->SUPER::new(undef, -1, 'Fruit Basket');

my @sizer = [];
$sizer[0] = Wx::BoxSizer->new(wxVERTICAL);
$sizer[0]->AddSpacer(14);
$sizer[1] = Wx::BoxSizer->new(wxHORIZONTAL);
$sizer[1]->AddSpacer(14);

my $FruitLabel = Wx::StaticText->new($dialog, -1, '&Fruit:');
$sizer[1]->Add($FruitLabel, 0, wxALIGN_LEFT | wxALIGN_TOP);
$sizer[1]->AddSpacer(6);

$FruitInput = Wx::TextCtrl->new($dialog, -1, '');
$sizer[1]->Add($FruitInput, 1, wxALIGN_LEFT | wxALIGN_TOP);
$sizer[1]->AddSpacer(8);

my $BasketLabel = Wx::StaticText->new($dialog, -1, '&Basket:');
$sizer[1]->Add($BasketLabel, 0, wxALIGN_LEFT | wxALIGN_TOP);
$sizer[1]->AddSpacer(6);

$BasketList = Wx::ListBox->new($dialog, -1, [-1, -1], [200, 100]);
$sizer[1]->Add($BasketList, 1, wxALIGN_LEFT | wxALIGN_TOP | wxGROW);
$sizer[1]->AddSpacer(14);

$sizer[0]->Add($sizer[1], 1, wxALIGN_CENTER_HORIZONTAL | wxALIGN_TOP);
$sizer[0]->AddSpacer(14);

$sizer[2] = Wx::BoxSizer->new(wxHORIZONTAL);
$sizer[2]->AddSpacer(14);

my $AddButton = Wx::Button->new($dialog, -1, '&Add');
$sizer[2]->Add($AddButton, 0, wxALIGN_LEFT | wxALIGN_TOP);
$sizer[2]->AddSpacer(8);
$AddButton->SetDefault;
EVT_BUTTON($dialog, $AddButton, \&OnAddButton);

my $DeleteButton = Wx::Button->new($dialog, -1, '&Delete');
$sizer[2]->Add($DeleteButton, 0, wxALIGN_LEFT | wxALIGN_TOP);
$sizer[2]->AddSpacer(14);
EVT_BUTTON($dialog, $DeleteButton, \&OnDeleteButton);

$sizer[0]->Add($sizer[2], 1, wxALIGN_CENTER_HORIZONTAL | wxALIGN_TOP);
$sizer[0]->AddSpacer(14);

$dialog->SetSizerAndFit($sizer[0]);
EVT_CLOSE($dialog, \&OnCloseWindow );
return $dialog;
}

sub OnCloseWindow {
my( $dialog, $event ) = @_;
$dialog->Destroy;
MyApp->MessageBox("Closing program.", "Alert");
exit;
}

sub OnAddButton{
my($dialog, $event) = @_;
my $fruit = $FruitInput->GetValue;
#if length($fruit) == 0 {
if(not $fruit) {
MyApp->MessageBox("Please enter a type of fruit.", "Alert");
}
else {
$BasketList->Append($fruit);
$FruitInput->Clear;
}
}
#}

sub OnDeleteButton{
my($dialog, $event) = @_;
my $index = $BasketList->GetSelection;
if($index < 0){
MyApp->MessageBox("No fruit to delete.", "Alert");
}
else {
$BasketList->Delete($index);
}
}

# Custom application blasss
package MyApp;
use base 'Wx::App';
sub OnInit {
my $dialog = MyDialog->new;
$dialog->ShowModal;
return 1;
}

sub MessageBox{
my $dialog = shift;
my($text, $title) = @_;
#Wx::MessageBox($text, $title, wxOK|wxICON_INFORMATION, $dialog);
Wx::MessageBox($text, $title);
}

sub OnAppExit {
exit;
}

package main;
my $app = MyApp->new;
$app->MainLoop;
