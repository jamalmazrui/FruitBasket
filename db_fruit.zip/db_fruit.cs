//File db_fruit.cs
//Fruit Basket program in C# with data binding and layout panels
//Public domain by Jamal Mazrui
//May 24, 2007

//Compile either in Visual Studio, or at a command prompt as follows:
//csc.exe /nologo /r:System.Data.SqLite.dll /t:winexe db_fruit.cs
//run db_fruit.exe with a parameter of either a for Microsoft Access or s for SQLite database support
//Case does not matter, and no parameter defaults to Access

using System;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SQLite;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

class Program {
static void Main(string[] sAppArgs) {
bool bSQLite = false;
if (sAppArgs.Length > 0  && sAppArgs[0].ToLower()[0] == 's') bSQLite = true;

Form frm = new Form();
frm.SuspendLayout();
frm.Text = "Fruit Basket";
frm.AutoSize = true;
frm.AutoSizeMode = AutoSizeMode.GrowAndShrink;

FlowLayoutPanel flpMain = new FlowLayoutPanel();
flpMain.SuspendLayout();
flpMain.AutoSize = true;
flpMain.AutoSizeMode  = AutoSizeMode.GrowAndShrink;
flpMain.FlowDirection = FlowDirection.TopDown;

FlowLayoutPanel flpData = new FlowLayoutPanel();
flpData.SuspendLayout();
flpData.AutoSize = true;
flpData.AutoSizeMode  = AutoSizeMode.GrowAndShrink;
flpData.FlowDirection = FlowDirection.LeftToRight;

Label lblFruit = new Label();
lblFruit.Text = "&Fruit:";

TextBox txtFruit = new TextBox();
txtFruit.AccessibleName = lblFruit.Text.Replace("&", "");

Label lblBasket = new Label();
lblBasket.Text = "&Basket:";

ListBox lstBasket = new ListBox();
lstBasket.AccessibleName = lblBasket.Text.Replace("&", "");

string sApp = System.Reflection.Assembly.GetExecutingAssembly().Location;
string sAppDir = Path.GetDirectoryName(sApp);
string sTable = "Basket";
string sDb, sMdb;
DataSet ds;
DataTable tbl;
SQLiteDataAdapter daDb = new SQLiteDataAdapter();
OleDbDataAdapter daMdb= new OleDbDataAdapter();

if (bSQLite) {
sDb = Path.Combine(sAppDir, "db_fruit.db");
string sSql = "create table " + sTable + " (ID integer primary key autoincrement, Fruit text);";
if (!File.Exists(sDb)) {
ExecuteDbSql(sDb, sSql);
}

string sConnectString = "Data Source=" + sDb;
SQLiteConnection con = new SQLiteConnection(sConnectString);
//con.ConnectionString = sConnectString;

String sSelectCommand = "select * from " + sTable + " order by ID desc";
SQLiteCommand cmd = new SQLiteCommand(sSelectCommand, con);

daDb = new SQLiteDataAdapter(cmd);

ds = new DataSet();
daDb.Fill(ds, sTable);
tbl = ds.Tables[0];

daDb.RowUpdated += delegate(object sender, System.Data.Common.RowUpdatedEventArgs e) {
if(e.StatementType == StatementType.Insert) {
SQLiteCommand cmdID = new SQLiteCommand("SELECT last_insert_rowid()", daDb.SelectCommand.Connection);
e.Row[0] = (Int64) cmdID.ExecuteScalar( );
}
};

SQLiteCommandBuilder cb = new SQLiteCommandBuilder(daDb);}
else {
sMdb = Path.Combine(sAppDir, "db_fruit.mdb");
string sSql = "create table " + sTable + " (ID counter constraint primarykey primary key, Fruit text(50))";
if (!File.Exists(sMdb)) {
CreateMdb(sMdb);
ExecuteMdbSql(sMdb, sSql);
}

string sConnectString = "Provider=Microsoft.JET.OLEDB.4.0;Data Source=" + sMdb;
OleDbConnection con = new OleDbConnection(sConnectString);
//con.ConnectionString = sConnectString;

String sSelectCommand = "select * from " + sTable + " order by ID desc";
OleDbCommand cmd = new OleDbCommand(sSelectCommand, con);

daMdb = new OleDbDataAdapter(cmd);

ds = new DataSet();
daMdb.Fill(ds, sTable);
tbl = ds.Tables[0];

daMdb.RowUpdated += delegate(object sender, OleDbRowUpdatedEventArgs e) {
if(e.StatementType == StatementType.Insert) {
OleDbCommand cmdID = new OleDbCommand("SELECT @@IDENTITY", daMdb.SelectCommand.Connection);
e.Row[0] = (int)cmdID.ExecuteScalar( );
}
};

OleDbCommandBuilder cb = new OleDbCommandBuilder(daMdb);
}

BindingSource bs = new BindingSource();
bs.DataSource = ds;
bs.DataMember = sTable;

lstBasket.DataSource = bs;
lstBasket.DisplayMember = "Fruit";

flpData.Controls.AddRange(new Control[] {lblFruit, txtFruit, lblBasket,
lstBasket});
flpData.ResumeLayout();

FlowLayoutPanel flpButtons = new FlowLayoutPanel();
flpButtons.SuspendLayout();
flpButtons.Anchor = AnchorStyles.None;
flpButtons.AutoSize = true;
flpButtons.AutoSizeMode  = AutoSizeMode.GrowAndShrink;
flpButtons.FlowDirection = FlowDirection.LeftToRight;

Button btnAdd = new Button();
btnAdd.Text = "&Add";
btnAdd.AccessibleName = btnAdd.Text.Replace("&", "");
btnAdd.Click += delegate(object o, EventArgs e) {
string sFruit = txtFruit.Text.Trim();
if (sFruit == "") MessageBox.Show("No fruit to add!", "Alert");
else {
//tbl.Rows.Add(-1, sFruit);
//add to top of basket instead of bottom
DataRow row = tbl.NewRow();
row["Fruit"] = sFruit;
tbl.Rows.InsertAt(row, 0);
bs.EndEdit();

//bs.Position = bs.Count - 1;
//select fruit just added
bs.Position = 0;
if (bSQLite) daDb.Update(tbl);
else daMdb.Update(tbl);
txtFruit.Clear();
}
};

Button btnDelete = new Button();
btnDelete.Text = "&Delete";
btnDelete.AccessibleName = btnDelete.Text.Replace("&", "");
btnDelete.Click += delegate(object o, EventArgs e) {
int iPosition = bs.Position;
if (iPosition == -1) MessageBox.Show("No fruit to delete!", "Alert");
else {
bs.RemoveAt(iPosition);
bs.EndEdit();
if (bSQLite) daDb.Update(tbl);
else daMdb.Update(tbl);
}
};

flpButtons.Controls.AddRange(new Control[] {btnAdd, btnDelete});
flpButtons.ResumeLayout();

flpMain.Controls.AddRange(new Control[] {flpData, flpButtons});
flpMain.ResumeLayout();

frm.Controls.Add(flpMain);
frm.AcceptButton = btnAdd;
frm.StartPosition = FormStartPosition.CenterScreen;
frm.Closing += delegate(object o, CancelEventArgs e) {
if (MessageBox.Show("Exit program?", "Confirm",
MessageBoxButtons.OKCancel) == DialogResult.Cancel) e.Cancel = true;};

frm.ResumeLayout();
frm.ShowDialog();
} // Main method

public static bool CreateMdb(string sMdb) {
string sConnectString = "Provider=Microsoft.JET.OLEDB.4.0;Data Source=" + sMdb;
Type ADOXCatalog = Type.GetTypeFromProgID("ADOX.Catalog");
object catalog = Activator.CreateInstance(ADOXCatalog);
object[] inputArguments = {sConnectString};
if (File.Exists(sMdb)) File.Delete(sMdb);
ADOXCatalog.InvokeMember("Create", BindingFlags.InvokeMethod, null, catalog, inputArguments);
bool bResult = File.Exists(sMdb);
return bResult;
} // CreateMdb method

public static int ExecuteMdbSql(string sMdb, string sSql) {
string sConnectString = "Provider=Microsoft.JET.OLEDB.4.0;Data Source=" + sMdb;
OleDbConnection connection = new OleDbConnection(sConnectString);
connection.Open();
OleDbCommand command = new OleDbCommand(sSql, connection);
int iResult = command.ExecuteNonQuery();
connection.Close();
return iResult;
} // ExecuteMdbSql method

public static int ExecuteDbSql(string sDb, string sSql) {
string sConnectString = "Data Source=" + sDb;
SQLiteConnection connection = new SQLiteConnection(sConnectString);
connection.Open();
SQLiteCommand command = new SQLiteCommand(sSql, connection);
int iResult = command.ExecuteNonQuery();
connection.Close();
return iResult;
} // ExecuteDbSql method

} // Program class
