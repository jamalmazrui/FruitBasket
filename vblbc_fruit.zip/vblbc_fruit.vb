' Fruit basket in Visual Basic 10 with Layout by Code
' June 23, 2010
' Public domain by Jamal Mazrui

' Require variables to be explicitly declared
Option Explicit On
' Require type casts to be explicitly done
Option Strict On

' Import namespaces
imports Homer
imports System
imports System.ComponentModel
imports System.Windows.Forms

' Declare a class named 'Dialog' that inherits from the class named 'LbcForm'
Class Dialog
Inherits LbcForm 

' Define the main event handler for this form
public Sub OnEvent(sEvent As String, oSender As Object, oArgs As EventArgs)
' Get references to the TextBox and ListBox widgets of this form
Dim txt As TextBox = me.GetTextBox("Fruit")
Dim lst As ListBox = me.GetListBox("Basket")

' Declare other local variables used in this event handler routine
Dim iCount, iIndex As Integer
Dim sFruit, sWidgetName As String

' Test for an event by name
Select Case sEvent
Case "Closing" 
If Lbc.DialogConfirm("Confirm", "Exit program?", "Y") <> "Y" Then CType(oArgs, CancelEventArgs).Cancel = True
Case "Click" 
' Test for a widget by name
sWidgetName = Lbc.GetName(oSender)
Select Case sWidgetName
Case "Button_Add" 
sFruit = txt.Text
If sFruit.Length = 0 Then 
Lbc.DialogShow("Alert", "No fruit to add!")
Else
lst.Items.Add(sFruit)
iIndex = lst.Items.Count - 1
lst.SelectedIndex = iIndex
txt.Clear()
End If
Case "Button_Delete" 
iIndex = lst.SelectedIndex
If iIndex = -1 Then
Lbc.DialogShow("Alert", "No fruit to delete!")
Else
lst.Items.RemoveAt(iIndex)
iCount = lst.Items.Count
If iCount = 0 Then Return
If iIndex = iCount Then iIndex -= 1
 lst.SelectedIndex = iIndex
End If
End Select
End Select
End Sub ' OnEvent method

' Define entry point of the program
Shared Sub Main() 

' Instantiate an object of the Dialog class
Dim dlg As Dialog = New Dialog()
End Sub ' Main method

' Define the constructor of the Dialog class
Sub New() 
' Set the dialog title
me.Init("Fruit Basket")

' Add a 'Fruit' label and a TextBox
me.AddInputBox("Fruit")

' Add a default button named 'Add'
me.AcceptButton = me.AddButton("Add")

' Start a new band of widgets
me.AddBand()

' Add a 'Basket' label and a ListBox
me.AddPickBox("Basket")

' Add a button named 'Delete'
me.AddButton("Delete")

' Complete setup of the dialog and activate it
me.CompleteDialog()
End Sub ' New method
End Class ' Dialog class
