# content of ps_fruit.ps1
# Fruit Basket program in PowerShell
# Public domain by Jamal Mazrui

$OnFruitBasketClosing = {
$event = $_
if ([Windows.Forms.MessageBox]::Show("Exit program?", "Confirm", "OKCancel") -eq "Cancel") {$event.Cancel = $true}
}

[reflection.assembly]::LoadWithPartialName("System.Drawing") > $null
[reflection.assembly]::LoadWithPartialName("System.Windows.Forms") > $null

$form = new-object Windows.Forms.Form
$form.SuspendLayout()
$form.Text = "Fruit Basket"
$form.AutoSize = $true
$form.AutoSizeMode = "GrowAndShrink"

$flpMain = new-object Windows.Forms.FlowLayoutPanel
$flpMain.SuspendLayout()
$flpMain.AutoSize = $true
$flpMain.AutoSizeMode  = "GrowAndShrink"
$flpMain.FlowDirection = "TopDown"

$flpData = new-object Windows.Forms.FlowLayoutPanel
$flpData.SuspendLayout()
$flpData.AutoSize = $true
$flpData.AutoSizeMode  = "GrowAndShrink"
$flpData.FlowDirection = "LeftToRight"

$lblFruit = new-object Windows.Forms.Label
$lblFruit.Text = "&Fruit:"

$txtFruit = new-object Windows.Forms.TextBox
$txtFruit.AccessibleName = $lblFruit.Text.Replace("&", "")

$lblBasket = new-object Windows.Forms.Label
$lblBasket.Text = "&Basket:"

$lstBasket = new-object Windows.Forms.ListBox
$lstBasket.AccessibleName = $lblBasket.Text.Replace("&", "")

$flpData.Controls.AddRange(($lblFruit, $txtFruit, $lblBasket, $lstBasket))
$flpData.ResumeLayout()

$flpButtons = new-object Windows.Forms.FlowLayoutPanel
$flpButtons.SuspendLayout()
$flpButtons.Anchor = "None"
$flpButtons.AutoSize = $true
$flpButtons.AutoSizeMode  = "GrowAndShrink"
$flpButtons.FlowDirection = "LeftToRight"

$btnAdd = new-object Windows.Forms.Button
$btnAdd.Text = "&Add"
$btnAdd.AccessibleName = $btnAdd.Text.Replace("&", "")
$btnAdd.add_Click({
$sFruit = $txtFruit.Text.Trim()
if ($sFruit -eq "") {
[Windows.Forms.MessageBox]::Show("No fruit to add!", "Alert")
return
}

$lstBasket.Items.Insert(0, $sFruit)
$lstBasket.SelectedIndex = 0
$txtFruit.Clear()
})

$btnDelete = new-object Windows.Forms.Button
$btnDelete.Text = "&Delete"
$btnDelete.AccessibleName = $btnDelete.Text.Replace("&", "")
$btnDelete.add_Click({
$iIndex = $lstBasket.SelectedIndex
if ($iIndex -eq -1) {
[Windows.Forms.MessageBox]::Show("No fruit to delete!", "Alert")
return
}

$lstBasket.Items.RemoveAt($iIndex)
$iCount = $lstBasket.Items.Count
if ($iIndex  -lt $iCount) {$lstBasket.SelectedIndex = $iIndex}
elseif ($iCount -gt 0) {$lstBasket.SelectedIndex = $iCount - 1}
})

$flpButtons.Controls.AddRange(($btnAdd, $btnDelete))
$flpButtons.ResumeLayout()

$flpMain.Controls.AddRange(($flpData, $flpButtons))
$flpMain.ResumeLayout()

$form.Controls.Add($flpMain)
$form.AcceptButton = $btnAdd
$form.StartPosition = "CenterScreen"
$form.add_Closing($OnFruitBasketClosing)
$form.ResumeLayout()
$form.ShowDialog()

# End of program
