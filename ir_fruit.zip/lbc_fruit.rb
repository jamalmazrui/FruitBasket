# Fruit Basket program in Iron Ruby
# Public domain by Jamal Mazrui
# May 10, 2010

# Import namespaces
require 'HomerLbc'
include Homer

def on_event(oSender, oArgs)
sEvent = 'Click'
sEvent = 'Closing' if oSender == $dlg

case sEvent
when 'Closing'
oArgs.Cancel = true if Lbc.DialogConfirm('Confirm', 'Exit program?', 'Y') != 'Y'
when 'Click'
case oSender.Name
when 'Button_Add'
sFruit = $txtFruit.Text
return Lbc.DialogShow('Alert', 'No fruit to add!') if sFruit.Length == 0

$lstBasket.Items.Add(sFruit)
iIndex = $lstBasket.Items.Count - 1
$lstBasket.SelectedIndex = iIndex
$txtFruit.Clear()

when 'Button_Delete'
iIndex = $lstBasket.SelectedIndex
return Lbc.DialogShow('Alert', 'No fruit to delete!') if iIndex == -1

$lstBasket.Items.RemoveAt(iIndex)
iCount = $lstBasket.Items.Count
return if iCount == 0
iIndex -- if iIndex == iCount
$lstBasket.SelectedIndex = iIndex
end
end
end
end # on_event function

$dlg = LbcForm.new('Fruit Basket')
$txtFruit = $dlg.AddInputBox('Fruit')
btnAdd = $dlg.AddButton('Add')
btnAdd.click.add method(:on_event)
$dlg.AcceptButton = btnAdd
$dlg.AddBand()
$lstBasket = $dlg.AddPickBox('Basket')
btnDelete = $dlg.AddButton('Delete')
btnDelete.click.add method(:on_event)
$dlg.Closing.add method(:on_event)
$dlg.CompleteDialog()
