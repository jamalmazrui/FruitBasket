-- Fruit basket program in Lua
-- Public domain by Jamal Mazrui

dlg = wx.wxDialog(wx.NULL, wx.wxID_ANY, "Fruit Basket", wx.wxDefaultPosition, wx.wxSize(513, 176))

lblFruit = wx.wxStaticText(dlg, wx.wxID_ANY, "&Fruit:", wx.wxPoint(14, 14), wx.wxDefaultSize)
txtFruit = wx.wxTextCtrl(dlg, wx.wxID_ANY, "", wx.wxPoint(43, 14), wx.wxDefaultSize, wx.wxTE_LEFT)

lblBasket = wx.wxStaticText(dlg, wx.wxID_ANY, "&Basket:", wx.wxPoint(251, 14), wx.wxDefaultSize)
lstBasket = wx.wxListBox(dlg, wx.wxID_ANY, wx.wxPoint(293,14), wx.wxDefaultSize, {})

btnAdd = wx.wxButton(dlg, wx.wxID_ANY, "&Add", wx.wxPoint(190, 121), wx.wxDefaultSize)
btnAdd:SetDefault()
dlg:Connect(btnAdd:GetId(), wx.wxEVT_COMMAND_BUTTON_CLICKED,
function(event)
sValue = txtFruit:GetValue()
if sValue == "" then
wx.wxMessageBox("No fruit to add!", "Alert", wx.wxICON_EXCLAMATION, dlg)
return
end

lstBasket:Append(sValue)
txtFruit:Clear()
iCount = lstBasket:GetCount()
iIndex = iCount - 1
lstBasket:SetSelection(iIndex)
end)

btnDelete = wx.wxButton(dlg, wx.wxID_ANY, "&Delete", wx.wxPoint(217, 121), wx.wxDefaultSize)
dlg:Connect(btnDelete:GetId(), wx.wxEVT_COMMAND_BUTTON_CLICKED,
function(event)
iIndex = lstBasket:GetSelection()
if iIndex == -1 then
wx.wxMessageBox("No fruit to delete!", "Alert", wx.wxICON_EXCLAMATION, dlg)
return
end

lstBasket:Delete(iIndex)
iCount = lstBasket:GetCount()
if iIndex == iCount then 
iIndex = iCount - 1
end

lstBasket:SetSelection(iIndex)
end)

dlg:Connect(wx.wxEVT_CLOSE_WINDOW,
function (event)
if wx.wxMessageBox("Exit program?", "Confirm", wx.wxYES_NO, dlg) == wx.wxYES then
event:Skip()
dlg:Destroy()
end
end)

dlg:Centre()
dlg:Show(true)
