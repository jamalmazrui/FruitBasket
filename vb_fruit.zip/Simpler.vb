' content of simpler.vb
' Fruit Basket program in Visual Basic 2005
' Public domain by Jamal Mazrui

' Import namespace
Imports System.Windows.Forms

Module FruitBasket
' Initialize controls
Dim tlp = new TableLayoutPanel()
Dim lblFruit = new Label()
Dim txtFruit = new TextBox()
Dim WithEvents btnAdd as Button = new Button()
Dim lblBasket = new Label()
Dim lstBasket = new ListBox()
Dim WithEvents btnDelete as Button = new Button()
Dim dlg = new Form()

' Define entry point of program
Sub Main()
' Specify control properties
With tlp
.ColumnCount = 3 : .RowCount = 2 : .Parent = dlg
.Controls.AddRange( new Control() {lblFruit, txtFruit, btnAdd, lblBasket, lstBasket, btnDelete})
End With

lblFruit.Text = "&Fruit:" : lblBasket.Text = "&Basket:"
btnAdd.Text = "&Add" : btnDelete.Text = "&Delete"

With dlg
.Text = "Fruit Basket" : .AcceptButton = btnAdd : .StartPosition = FormStartPosition.CenterScreen : .AutoSize = True : .AutoSizeMode = AutoSizeMode.GrowAndShrink
.ShowDialog()
End With
End Sub

' Define event handler
Sub Button_Click(sender as Object, e as EventArgs) Handles btnAdd.Click, btnDelete.Click
Select Case sender.Text
case "&Add"
Dim sFruit = txtFruit.Text
if sFruit = "" Then 
MessageBox.Show("No fruit to add!", "Alert")
Return
End If

lstBasket.Items.Add(sFruit)
txtFruit.Text = ""
lstBasket.SelectedIndex = lstBasket.Items.Count - 1

Case "&Delete"
Dim iFruit = lstBasket.SelectedIndex
if iFruit = (-1) Then
MessageBox.Show("No fruit to delete.", "Alert")
Return
End If

lstBasket.Items.RemoveAt(iFruit)
if iFruit > (lstBasket.Items.Count - 1) Then iFruit = (lstBasket.Items.Count - 1)
lstBasket.SelectedIndex = iFruit
End Select
End Sub
End Module

