' content of vb_fruit.vb
' Fruit Basket program in Visual Basic 2005
' Public domain by Jamal Mazrui

' Import namespace
Imports System.Windows.Forms

Module FruitBasket
' Initialize dialog and controls
Dim dlg = new Form()
Dim lblFruit = new Label()
Dim txtFruit = new TextBox()
Dim WithEvents btnAdd as Button = new Button()
Dim lblBasket = new Label()
Dim lstBasket = new ListBox()
Dim WithEvents btnDelete as Button = new Button()

' Define entry point of program
Sub Main()
' Specify control properties
With lblFruit
.Text = "&Fruit:" : .Left = 14 : .Top = 14 : .Width = 44 : .Height = 16 : .Parent = dlg
End With

With txtFruit
.Left = 64 : .Top = 14 : .Width = 200 : .Height = 16 : .Parent = dlg
End With

With btnAdd
.Text = "&Add" : .Left = 272 : .Top = 14 : .Width = 100 : .Height = 20 : .Parent = dlg
End With

With lblBasket
.Text = "&Basket:" : .Left = 14 : .Top = 38 : .Width = 44 : .Height = 16 : .Parent = dlg
End With

With lstBasket
.Left = 64 : .Top = 38 : .Width = 200 : .Height = 200 : .Parent = dlg
End With

With btnDelete
.Text = "&Delete" : .Left = 272 : .Top = 38 : .Width = 100 : .Height = 20 : .Parent = dlg
End With

With dlg
.Text = "Fruit Basket" : .StartPosition = FormStartPosition.CenterScreen : .Width = 400 : .Height = 285 : .AcceptButton = btnAdd
.ShowDialog()
End With
End Sub

' Define event handler
Sub Button_Click(sender as Object, e as EventArgs) Handles btnAdd.Click, btnDelete.Click
If sender is btnAdd Then
Dim sFruit = txtFruit.Text
if sFruit = "" Then 
MessageBox.Show("No fruit to add!", "Alert")
Return
End If

lstBasket.Items.Add(sFruit)
txtFruit.Text = ""
lstBasket.SelectedIndex = lstBasket.Items.Count - 1

Else If sender is btnDelete Then
Dim iFruit = lstBasket.SelectedIndex
if iFruit = (-1) Then
MessageBox.Show("No fruit to delete.", "Alert")
Return
End If

lstBasket.Items.RemoveAt(iFruit)
if iFruit > (lstBasket.Items.Count - 1) Then iFruit = (lstBasket.Items.Count - 1)
lstBasket.SelectedIndex = iFruit
End If
End Sub
End Module

