/*
content of cli_fruit.cpp;
Fruit Basket program in C++/CLI
public domain by Jamal Mazrui
*/

// Reference libraries
#using <System.dll>
#using <System.Windows.Forms.dll>

// Import namespaces
using namespace System;
using namespace System::Windows::Forms;

// Define class
ref class FruitBasket : public Form {
public :
//Define constructor
FruitBasket() {
// Initialize controls and set properties
tlp = gcnew TableLayoutPanel();
tlp->ColumnCount = 3;
tlp->RowCount = 2;

lblFruit = gcnew Label();
lblFruit->Text = "&Fruit:";
tlp->Controls->Add(lblFruit);

txtFruit = gcnew TextBox();
tlp->Controls->Add(txtFruit);

btnAdd = gcnew Button();
btnAdd->Text = "&Add";
btnAdd->Click += gcnew EventHandler(this, &FruitBasket::Button_Click);
tlp->Controls->Add(btnAdd);

lblBasket = gcnew Label();
lblBasket->Text = "&Basket:";
tlp->Controls->Add(lblBasket);

lstBasket = gcnew ListBox();
tlp->Controls->Add(lstBasket);

btnDelete = gcnew Button();
btnDelete->Text = "&Delete";
btnDelete->Click += gcnew EventHandler(this, &FruitBasket::Button_Click);
tlp->Controls->Add(btnDelete);

Text = "Fruit Basket";
AcceptButton = btnAdd;
StartPosition = FormStartPosition::CenterScreen;
AutoSize = true;
AutoSizeMode = System::Windows::Forms::AutoSizeMode::GrowAndShrink;
Controls->Add(tlp);
} // FruitBasket constructor

// Define destructor
virtual ~FruitBasket() {
} // FruitBasket destructor

// Define event handler;
void Button_Click(Object^ sender, EventArgs^ e) { 
if (sender == btnAdd) { 
String^ sFruit = txtFruit->Text->Trim();
if (sFruit->Length == 0) { 
MessageBox::Show("No fruit to add!", "Alert"); 
return;
}

lstBasket->Items->Add(sFruit);
txtFruit->Clear();
lstBasket->SelectedIndex = lstBasket->Items->Count - 1;
}

else if (sender == btnDelete) {
int iFruit = lstBasket->SelectedIndex;
if (iFruit == -1) {
MessageBox::Show("No fruit to delete->", "Alert"); 
return;
}

lstBasket->Items->RemoveAt(iFruit);
if (iFruit == lstBasket->Items->Count) iFruit--;
lstBasket->SelectedIndex = iFruit;
}
} // Button_Click event handler

// Declare controls;
TableLayoutPanel^ tlp;
Label^ lblFruit;
TextBox^ txtFruit;
Button^ btnAdd;
Label^ lblBasket;
ListBox^ lstBasket;
Button^ btnDelete;
}; // FruitBasket class

// Define entry point of program
int main() {
Application::Run(gcnew FruitBasket());
return 0;
} // main method

// End of cli_fruit.cpp
