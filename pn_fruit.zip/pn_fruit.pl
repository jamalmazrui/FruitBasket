#Fruit basket program in Perl for .NET
#Public domain by Jamal Mazrui

package FruitBasket;
use strict;
use PerlNET qw(AUTOCALL enum with true false);

use namespace "System";
use namespace "System.Drawing";
use namespace "System.Windows.Forms";

=for interface
[extends: Form]
private field System.Windows.Forms.TextBox Fruit;
private field System.Windows.Forms.ListBox Basket;
private void btnAdd_Click(System.Object sender, System.EventArgs evArgs);
private void btnDelete_Click(System.Object sender, System.EventArgs evArgs);
=cut

my $self = FruitBasket->new();
Application->Run($self);

sub FruitBasket {
my $this = shift;
my ($flpMain, $flpData, $flpButtons);
my ($lblFruit, $lblBasket, $btnAdd, $btnDelete);
my ($txtFruit, $lstBasket);

with ($flpMain = FlowLayoutPanel->new(),
AutoSize => true,
AutoSizeMode => enum("AutoSizeMode.GrowAndShrink"),
FlowDirection => enum("FlowDirection.TopDown"));

with ($flpData = FlowLayoutPanel->new(),
AutoSize => true,
AutoSizeMode => enum("AutoSizeMode.GrowAndShrink"),
FlowDirection => enum("FlowDirection.LeftToRight"));

with ($lblFruit = Label->new(),
Text => "&Fruit:");

$txtFruit = TextBox->new();

with ($lblBasket = Label->new(),
Text => "&Basket:");

$lstBasket = ListBox->new();

$flpData->{Controls}->Add($_) for $lblFruit, $txtFruit, $lblBasket, $lstBasket;

with ($flpButtons = FlowLayoutPanel->new(),
AutoSize => true,
AutoSizeMode => enum("AutoSizeMode.GrowAndShrink"),
FlowDirection => enum("FlowDirection.LeftToRight"));

with ($btnAdd = Button->new(),
Text => "&Add");
$btnAdd->add_Click(EventHandler->new($this, "btnAdd_Click"));

with ($btnDelete = Button->new(),
Text => "&Delete");
$btnDelete->add_Click(EventHandler->new($this, "btnDelete_Click"));

$flpButtons->{Controls}->Add($_) for $btnAdd, $btnDelete;
$flpMain->{Controls}->Add($_) for $flpData, $flpButtons;
$this->{Controls}->Add($flpMain);

with ($this,
AcceptButton => $btnAdd,
StartPosition => enum("FormStartPosition.CenterScreen"),
Text => "Fruit Basket",
Fruit => $txtFruit,
Basket => $lstBasket);
}

sub btnAdd_Click {
my($this, $sender, $evargs) = @_;
my $sFruit = $this->{Fruit}->{Text};
unless ($sFruit) {
MessageBox->Show("No fruit to add!", "Alert");
return;
}

$this->{Basket}->{Items}->Insert(0, $sFruit);
$this->{Basket}->{SelectedIndex} = 0;
$this->{Fruit}->Clear();
}

sub btnDelete_Click {
my($this, $sender, $evargs) = @_;
my $iFruit = $this->{Basket}->{SelectedIndex};
if ($iFruit == -1) {
MessageBox->Show("No fruit to delete!", "Alert");
return;
}

$this->{Basket}->{Items}->RemoveAt($iFruit);
$iFruit = $this->{Basket}->{Items}->{Count} - 1 if $iFruit > $this->{Basket}->{Items}->{Count} - 1;
$this->{Basket}->{SelectedIndex} = $iFruit;
}

#End of program
