# Fruit Basket program in PyDent with WxWidgets
# Public domain by Jamal Mazrui

import wx

def Add_Click(event):
	sFruit = txtFruit.GetValue()
	if len(sFruit ) == 0:
		wx.MessageBox("No fruit to add!", "Alert")
	#if
	else:
		lstBasket.Append(sFruit)
		iFruit = lstBasket.GetCount() - 1
		lstBasket.SetSelection(iFruit)
		txtFruit.Clear()
	#else
#def

def Delete_Click(event):
	iFruit = lstBasket.GetSelection()
	if iFruit == -1:
		wx.MessageBox("No fruit to delete!.", "Alert")
	#if
	else:
		lstBasket.Delete(iFruit)
		if iFruit == lstBasket.GetCount(): iFruit = iFruit - 1
		lstBasket.SetSelection(iFruit)
	#else
#def

def FruitBasket_Close(event):
	if wx.MessageBox("Exit program?", "Confirm", wx.YES_NO) == wx.YES : dlg.Destroy()
#def

# Main program
app = wx.PySimpleApp()
dlg = wx.Dialog(None, -1, "Fruit Basket")
sizer = wx.FlexGridSizer(cols=3, hgap=6, vgap=8)
lblFruit = wx.StaticText(dlg, -1, "&Fruit:")
sizer.Add(lblFruit)
txtFruit = wx.TextCtrl(dlg)
sizer.Add(txtFruit)
btnAdd = wx.Button(dlg, -1, "&Add")
sizer.Add(btnAdd)
lblBasket = wx.StaticText(dlg, -1, "&Basket:")
sizer.Add(lblBasket)
lstBasket = wx.ListBox(dlg)
sizer.Add(lstBasket)
btnDelete = wx.Button(dlg, -1, "&Delete")
sizer.Add(btnDelete)

btnAdd.SetDefault()
dlg.Bind(wx.EVT_BUTTON, Add_Click, btnAdd)
dlg.Bind(wx.EVT_BUTTON, Delete_Click, btnDelete)
dlg.Bind(wx.EVT_CLOSE, FruitBasket_Close, dlg)

dlg.SetSizerAndFit(sizer)
dlg.Show()
app.MainLoop()
