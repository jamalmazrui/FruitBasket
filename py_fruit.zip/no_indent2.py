"""
Fruit basket program in Python with no indentation
Public domain by Jamal Mazrui
April 7, 2009

The indentation requirement of the Python programming language aids 
its visual readability, but poses perhaps its biggest challenge to 
blind users of speech output.  The challenge is manageable, as 
demonstrated by a number of successful blind programmers.  Techniques 
typically focus on ways of efficiently querying or adjusting 
indentation with speech in order to follow the logical structure of 
code.  

This sample program instead uses techniques that avoid the need for 
indentation, itself, by exploiting other features of the language.  
The Python code is valid and functional, though not conventional in 
style.

The first technique defines a function for executing a block of 
statements in an in-line event handler -- also called an 'anonymous 
delegate.'  The multiple lines of code are enclosed in a triple 
quoted string.  At runtime, the custom execute function is called by 
the built-in lambda function, which must be passed an expression 
rather than statement(s).

Within event handling code, parts of a compound statement are put on 
a single logical line that is split among multiple physical lines.  
In the Add handler, a tuble is used to combine sequential tasks.  
The unbalanced opening parenthesis on the line that starts the tuple 
enables each of its expression items to be placed on a seperate 
line.  In the Delete handler, a semicolon (;) and backslash (\) are 
used, as well as an in-line 'if' expression.

The resulting program implements the criteria of a fruit basket 
program in Python without needing any indentation.  Moreover, the 
code is more scripting-like because all variables defined are 
accessible globally, and no explicit class structures are needed.  
The techniques are not necessarily recommended, but they hopefully 
show additional possibilities for overcoming the indentation 
requirement of a popular language.
"""

# Import wxWidgets package
import wx

# Define function that executes a block of statements
def execute(sCode): exec sCode

# Initialize program and dialog
app = wx.PySimpleApp()
dlg = wx.Dialog(parent=None, title='Fruit Basket')

# Handle Close event
dlg.Bind(wx.EVT_CLOSE, lambda event: execute("""
if wx.MessageBox('Exit program?', 'Confirm', wx.YES_NO) == wx.YES: dlg.Destroy()
"""))

# Define first row of controls
lblFruit = wx.StaticText(parent=dlg, label='&Fruit:')
txtFruit = wx.TextCtrl(parent=dlg)
btnAdd = wx.Button(parent=dlg, label='&Add')

# Handle Add event
btnAdd.SetDefault()
btnAdd.Bind(wx.EVT_BUTTON, lambda event: execute("""
sFruit = txtFruit.GetValue()
if len(sFruit ) == 0: wx.MessageBox('No fruit to add!', 'Alert')
else: (
lstBasket.Insert(sFruit, 0),
lstBasket.SetSelection(0),
txtFruit.Clear()
)
"""))

# Define second row of controls
lblBasket = wx.StaticText(parent=dlg, label='&Basket:')
lstBasket = wx.ListBox(parent=dlg)
btnDelete = wx.Button(parent=dlg, label='&Delete')

# Handle Delete event
btnDelete.Bind(wx.EVT_BUTTON, lambda event: execute("""
iIndex = lstBasket.GetSelection()
iCount = lstBasket.GetCount()
if iIndex == -1: wx.MessageBox('No fruit to delete!', 'Alert')
else:\
lstBasket.Delete(iIndex);\
 lstBasket.SetSelection(min(iIndex, iCount)) if iCount > 1 else None
"""))

# Define layout sizer
sizer = wx.FlexGridSizer(cols=3, hgap=6, vgap=8)
for widget in (lblFruit, txtFruit, btnAdd, lblBasket, lstBasket, btnDelete): sizer.Add(widget)
dlg.SetSizerAndFit(sizer)

# Activate dialog and run program
dlg.Show()
app.MainLoop()
